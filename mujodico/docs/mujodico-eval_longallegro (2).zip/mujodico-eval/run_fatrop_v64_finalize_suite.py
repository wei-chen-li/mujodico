#!/usr/bin/env python3
"""Apply v64, verify Fingers watchdog timing, then launch all-five-task quality sweep."""
from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path

from install_fatrop_v64_stack import main as _unused  # import checks local dependencies
from apply_fatrop_v64_watchdog_timing_patch import solver_path
from install_fatrop_v64_stack import ensure_restoration
from apply_fatrop_v29_watchdog_patch import apply_patch as apply_v29
from apply_fatrop_v44_integration_patch import apply_patch as apply_v44
from apply_fatrop_v64_watchdog_timing_patch import apply_patch as apply_v64
from inspect_fatrop_v64 import inspect_watchdog

TASKS=['PushSphere2d','PushBox2d','PushCircularKnob','PushSquareKnob','FingersSphere2d']
CONFIGS=['serial-cpu-f64','pas-cpu-f64','official-cpu-f64']


def install():
    sp=solver_path();txt=sp.read_text()
    if '# V29_EXACT_WATCHDOG_RETRY' not in txt: apply_v29(sp)
    ensure_restoration(sp)
    txt=sp.read_text()
    if '# V44_INTEGRATED_NATIVE_RESTORATION' not in txt: apply_v44(sp)
    apply_v64(sp)


def call_suite(args):
    suite=Path(__file__).with_name('benchmark_fatrop_v64_suite.py')
    print('RUN:',' '.join(map(str,args)),flush=True)
    return subprocess.call([sys.executable,str(suite),*map(str,args)])


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--timeout',type=float,default=1800)
    ap.add_argument('--quality-iters',type=int,default=150)
    ap.add_argument('--skip-smoke',action='store_true')
    ap.add_argument('--smoke-dir',default='fatrop_v64_watchdog_smoke')
    ap.add_argument('--outdir',default='fatrop_v64_five_task_quality')
    ap.add_argument('--fatrop-lib',default='')
    ap.add_argument('--blasfeo-lib',default='')
    a=ap.parse_args()
    install()

    libargs=[]
    if a.fatrop_lib: libargs += ['--fatrop-lib',a.fatrop_lib]
    if a.blasfeo_lib: libargs += ['--blasfeo-lib',a.blasfeo_lib]

    if not a.skip_smoke:
        rc=call_suite([
            '--tasks','FingersSphere2d',
            '--configs',*CONFIGS,
            '--max-iters','20','--repeats','1','--warmup-runs','0',
            '--print-level','1','--per-run-timeout',str(a.timeout),
            '--outdir',a.smoke_dir,*libargs,
        ])
        if rc: raise SystemExit(rc)
        log=Path(a.smoke_dir)/'FingersSphere2d__serial-cpu-f64.log'
        chk=inspect_watchdog(log)
        print('V64_WATCHDOG_CHECK '+json.dumps(chk,sort_keys=True),flush=True)
        if not chk.get('ok'):
            raise SystemExit(
                'Watchdog timing smoke did not show exactly two committed w rows before restoration; '
                'five-task sweep intentionally not started.'
            )

    rc=call_suite([
        '--tasks',*TASKS,
        '--configs',*CONFIGS,
        '--max-iters',str(a.quality_iters),'--repeats','1','--warmup-runs','0',
        '--print-level','0','--per-run-timeout',str(a.timeout),
        '--outdir',a.outdir,*libargs,
    ])
    raise SystemExit(rc)

if __name__=='__main__': main()
