# MuJoDiCo (Multi-Joint dynamics with Differentiable Contact)

This package extends MuJoCo with differentiable contact dynamics and provides trajectory optimization algorithms for contact-rich dynamical systems. Gradients are computed using the implicit function theorem rather than differentiating through the solver rollout.

## Installation

```sh
pip install -e .
```

## Usage

[MuJoDiCo](https://github.com/wei-chen-li/mujodico) is a drop-in replacement for [MuJoCo MJX](https://mujoco.readthedocs.io/en/stable/mjx.html) that provides differentiable contact dynamics. You can simply replace `from mujoco import mjx` with `from mujodico import mjx`. For example:

```python
import jax
import jax.numpy as jnp
import mujoco
from mujodico import mjx

model = mujoco.MjModel.from_xml_string(XML)

mjx_model = mjx.put_model(
    model,
    contact_approximation='Hunt-Crossley',
    contact_smoothing=0.0,
)

def f(x, u):
    nq, nv = mjx_model.nq, mjx_model.nv
    d = mjx.make_data(mjx_model)
    d = d.replace(qpos=x[:nq], qvel=x[nq:nq+nv], act=x[nq+nv:], ctrl=u)
    d = mjx.step(mjx_model, d)
    x_next = jnp.concatenate((d.qpos, d.qvel, d.act))
    return x_next

x = jnp.zeros(mjx_model.nq + mjx_model.nv + mjx_model.na)
u = jnp.zeros(mjx_model.nu)

A, B = jax.jacfwd(f, argnums=(0,1))(x, u)
```

MuJoDiCo computes dynamics Jacobian using the implicit function theorem. Both forward-mode (`jax.jacfwd`) and reverse-mode (`jax.jacrev`) differentiation are supported.

### Contact Modeling

MuJoDiCo provides configurable contact models through two parameters:

* **`contact_approximation`** — specifies the contact model used for the dynamics. `'Hunt-Crossley'` is recommended for most applications.
* **`contact_smoothing`** — adds artificial smoothing to the contact model to make the resulting dynamics **C¹-continuous**.

The `contact_smoothing=κ` parameter controls the amount of regularization. It can be interpreted as applying a force of κ newtons over a distance of 1 meter.

For forward simulation, where differentiability is not required, use `contact_smoothing=0.0`.
For trajectory optimization or other gradient-based methods that require C¹-continuous dynamics, `contact_smoothing=1e-5` is a good starting point, providing smooth dynamics while introducing relatively little unphysical behavior.

### Examples

```sh
python -m mujodico.examples --help
```

### FATROP contact benchmark

The contact benchmark compares the JAX serial/PAS reference against the
CasADi FATROP oracle. Official solutions can be cached because that solve is
substantially slower:

```sh
python benchmark_fatrop_v64_one.py --task PushSphere2d --solver official \
  --official-cache /tmp/fatrop/PushSphere2d.npz
python benchmark_fatrop_v64_one.py --task PushSphere2d --solver jax-pas
```

The same JAX/PAS solver is also available through the examples runner:

```sh
python -m mujodico.examples \
  --method JaxPasFatropLiftedMultipleShooting \
  --contact_approx hunt-crossley \
  --task PushSphere2d \
  --iterations 100 \
  --tests 100
```

Use `--hess_approx full` to select the exact Lagrangian Hessian; the default
`gaussnewton` setting uses the FATROP cost Hessian approximation. With one
test, the command starts the existing Viser animation automatically.

For a CPU-oriented run, use stagewise derivatives. For a GPU-oriented speed
run, use the device-side ordinary line search:

```sh
JAX_ENABLE_X64=True JAX_PLATFORMS=cpu \
python -m mujodico.examples --method JaxPasFatropLiftedMultipleShooting \
  --contact_approx hunt-crossley --task PushBox2d --iterations 150 \
  --tests 1 --warmup 1 --stagewise true --jax_cache /tmp/jax-fatrop-cpu-cache

JAX_ENABLE_X64=True JAX_PLATFORMS=cuda \
python -m mujodico.examples --method JaxPasFatropLiftedMultipleShooting \
  --contact_approx hunt-crossley --task PushBox2d --iterations 150 \
  --tests 1 --warmup 1 --gpu_line_search --jax_cache /tmp/jax-fatrop-gpu-cache
```

The GPU line-search mode disables SOC corrections for speed and is intended
as a performance configuration rather than a strict trajectory-equivalence
configuration.

The JAX benchmark uses ordinary filter globalization by default. The
experimental watchdog path can be enabled with `--enable-watchdog`.

### Viser trajectory comparison

The cached official and JAX trajectories can be viewed and animated together
with the task's existing MuJoCo and Plotly visualization hooks:

```sh
python visualize_fatrop_v64.py --task PushSphere2d \
  --official /tmp/fatrop-correctness/PushSphere2d__official-cpu-f64.npz \
  --jax /tmp/pas_pushsphere_f64_150.npz
```

Open the printed localhost URL. Use the trajectory dropdown to switch
solvers, the timestep slider to scrub, and `play` to animate. For another
task, pass its cached `--official` and `--jax` files explicitly.

## Versioning

The `major.minor.micro` portion of the version number matches the version of MuJoCo. Optionally, if we release updates to MuJoDiCo that target the same version of MuJoCo, a `.postN` suffix is added, for example `3.0.1.post2` represents the second update to MuJoDiCo for MuJoCo 3.0.1.

## License and Disclaimer

MuJoDiCo is licensed under the Apache License, Version 2.0. You may obtain a copy of the License at https://www.apache.org/licenses/LICENSE-2.0.

This project includes code adapted from [MuJoCo](https://github.com/google-deepmind/mujoco), which is licensed under Apache License, Version 2.0. You may obtain a copy of the License at https://www.apache.org/licenses/LICENSE-2.0.
