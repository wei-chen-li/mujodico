"""Plot the four state quantities shown in the Allegro-ball Viser plot.

Example:
  python plot_allegro_ball_state.py allegro_ball_180deg_plot_data.npz \
      --output allegro_ball_180deg_state.pdf
"""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def main():
  parser = argparse.ArgumentParser()
  parser.add_argument('data', type=Path)
  parser.add_argument('--output', type=Path, required=True)
  parser.add_argument('--latex', action='store_true')
  args = parser.parse_args()

  with np.load(args.data) as data:
    time = data['x']
    values = [
        data['x_position'],
        data['y_position'],
        data['z_position'],
        data['quaternion_error'],
    ]
    goals = data['position_goals'] if 'position_goals' in data else None

  rc_params = {
      'font.family': 'serif',
      'mathtext.fontset': 'cm',
      'axes.labelsize': 16.5,
      'axes.titlesize': 16.5,
      'xtick.labelsize': 13.5,
      'ytick.labelsize': 13.5,
  }
  if args.latex:
    rc_params.update({
        'text.usetex': True,
        'font.serif': ['Computer Modern'],
    })
  plt.rcParams.update(rc_params)
  fig, axes = plt.subplots(
      4, 1, figsize=(5.2, 6.2), sharex=True, constrained_layout=True
  )
  labels = [
      r'$p_x$ [m]',
      r'$p_y$ [m]',
      r'$p_z$ [m]',
      r'$\mathrm{quaternion}$',
  ]
  colors = ['#4267ac', '#4c956c', '#bc4749', '#7b2cbf']

  for i, (ax, value, label, color) in enumerate(zip(axes, values, labels, colors)):
    ax.plot(time, value, color=color, linewidth=1.8)
    if goals is not None and i < 3:
      ax.axhline(
          goals[i], color='0.35', linewidth=0.8, linestyle=(0, (4, 3))
      )
    ax.set_ylabel(label)
    ax.grid(axis='y', color='0.88', linewidth=0.7)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.margins(x=0.01)

  axes[-1].set_xlabel(r'$\mathrm{Time\ (s)}$')
  args.output.parent.mkdir(parents=True, exist_ok=True)
  output = args.output.with_suffix('.pdf')
  fig.savefig(output, format='pdf', bbox_inches='tight')
  print(output)


if __name__ == '__main__':
  main()
