#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

ITER_RE = re.compile(r"^\s*(\d+)\s+.*?([xhfHwFr])\s*$")
ENTER_RE = re.compile(r"V44_RESTORATION_ENTER it=(\d+) J=([0-9.eE+-]+) cv=([0-9.eE+-]+)")
HAND_RE = re.compile(r"V44_RESTORATION_HANDOFF it=(\d+) J=([0-9.eE+-]+) cv=([0-9.eE+-]+)")


def inspect_watchdog(log: Path):
    lines=log.read_text(errors='replace').splitlines()
    enter_i=None; enter=None
    for j,line in enumerate(lines):
        m=ENTER_RE.search(line)
        if m:
            enter_i=j;enter=(int(m.group(1)),float(m.group(2)),float(m.group(3)));break
    if enter_i is None:
        return {'ok':False,'reason':'no restoration entry found'}
    # Count contiguous accepted outer watchdog rows immediately preceding entry.
    ws=[]
    for line in reversed(lines[:enter_i]):
        m=ITER_RE.match(line)
        if not m: continue
        typ=m.group(2)
        if typ=='w': ws.append(int(m.group(1))); continue
        break
    ws=list(reversed(ws))
    hand=None
    for line in lines[enter_i:]:
        m=HAND_RE.search(line)
        if m:
            hand=(int(m.group(1)),float(m.group(2)),float(m.group(3)));break
    return {
        'ok': len(ws)==2,
        'watchdog_rows_before_first_restoration': ws,
        'restoration_enter': enter,
        'restoration_handoff': hand,
        'expected_signature':'two committed w rows, then restoration on the next failed watchdog trial',
    }


def summarize_results(path: Path):
    if not path.exists(): return []
    rows=json.loads(path.read_text())
    by={}
    for r in rows:
        by.setdefault(r.get('task','?'),{})[r.get('config','?')]=r
    out=[]
    for task,cfgs in by.items():
        row={'task':task}
        for cfg,r in cfgs.items():
            key=cfg.replace('-cpu-f64','').replace('-','_')
            row[key+'_status']=r.get('status')
            row[key+'_goal']=r.get('physical_goal')
            row[key+'_obj']=r.get('objective')
            row[key+'_time']=r.get('median_seconds')
        s=cfgs.get('serial-cpu-f64');p=cfgs.get('pas-cpu-f64')
        if s and p:
            try: row['serial_pas_goal_absdiff']=abs(float(s['physical_goal'])-float(p['physical_goal']))
            except Exception: pass
            try: row['serial_pas_obj_absdiff']=abs(float(s['objective'])-float(p['objective']))
            except Exception: pass
        out.append(row)
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('outdir',nargs='?',default='fatrop_v64_five_task_quality')
    ap.add_argument('--smoke-dir',default='fatrop_v64_watchdog_smoke')
    a=ap.parse_args()
    smoke=Path(a.smoke_dir)/'FingersSphere2d__serial-cpu-f64.log'
    if smoke.exists():
        print('WATCHDOG SMOKE')
        print(json.dumps(inspect_watchdog(smoke),indent=2,sort_keys=True))
    results=Path(a.outdir)/'results.json'
    if results.exists():
        print('\nFIVE-TASK SUMMARY')
        print(json.dumps(summarize_results(results),indent=2,sort_keys=True))

if __name__=='__main__': main()
