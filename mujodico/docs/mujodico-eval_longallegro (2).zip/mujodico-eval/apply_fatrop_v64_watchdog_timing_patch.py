#!/usr/bin/env python3
"""Fix FATROP watchdog exhaustion timing without touching KKT/SOC/restoration.

Observed native FATROP Fingers transition:
    10 checkpoint
    11 w
    12 w
    13 r   (third rejected watchdog trial restores checkpoint BEFORE a w row)

The v44 branch inherited the old condition
    watchdog_steps > opt.max_watchdog_steps
which commits one extra watchdog point.  With the default max_watchdog_steps=3,
changing only this comparison to >= makes the third rejected watchdog trial
restore the checkpoint and enter the already-validated v43/v44 restoration
before the outer `w` row is recorded.
"""
from __future__ import annotations
import argparse
import py_compile
import re
import shutil
from pathlib import Path

MARKER = "# V64_NATIVE_WATCHDOG_EXHAUSTION_TIMING"


def solver_path() -> Path:
    import mujodico.trajopt._src.fatrop_ref.solver as sm
    return Path(sm.__file__).resolve()


def apply_patch(path: Path) -> bool:
    txt = path.read_text()
    if MARKER in txt:
        print(f"V64 watchdog timing patch already installed: {path}")
        return False
    if "# V44_INTEGRATED_NATIVE_RESTORATION" not in txt:
        raise RuntimeError(
            "V64 expects the validated v44 restoration integration first. "
            "Run install_fatrop_v64_stack.py, or apply v29+v44 before v64.\n"
            f"Solver: {path}"
        )

    # Restrict the replacement to the watchdog-rejected bookkeeping branch
    # immediately preceding V44 restoration, rather than globally changing any
    # unrelated max-step comparison.
    pat = re.compile(
        r"(?P<i>[ ]+)if watchdog_active and watchdog_rejected_trial:\n"
        r"(?P=i)    watchdog_steps\+=1\n"
        r"(?P=i)    if watchdog_steps>opt\.max_watchdog_steps:\n"
        r"(?P=i)        if watchdog_checkpoint is not None:\n"
        r"(?P=i)            wb=watchdog_checkpoint\n"
        r"(?P=i)            # V44_INTEGRATED_NATIVE_RESTORATION\n"
    )
    m = pat.search(txt)
    if m is None:
        # Allow whitespace around the comparison for evolved local branches.
        pat = re.compile(
            r"(?P<i>[ ]+)if watchdog_active and watchdog_rejected_trial:\n"
            r"(?P=i)    watchdog_steps\s*\+=\s*1\n"
            r"(?P=i)    if watchdog_steps\s*>\s*opt\.max_watchdog_steps:\n"
            r"(?P=i)        if watchdog_checkpoint is not None:\n"
            r"(?P=i)            wb=watchdog_checkpoint\n"
            r"(?P=i)            # V44_INTEGRATED_NATIVE_RESTORATION\n"
        )
        m = pat.search(txt)
    if m is None:
        raise RuntimeError(
            "Could not locate the v44 watchdog-exhaustion branch. "
            "No solver equations were modified. Send the current solver.py if needed."
        )

    old = m.group(0)
    new = old.replace(
        "watchdog_steps>opt.max_watchdog_steps:",
        "watchdog_steps>=opt.max_watchdog_steps:  # V64_NATIVE_WATCHDOG_EXHAUSTION_TIMING",
        1,
    )
    if new == old:
        new = re.sub(
            r"watchdog_steps\s*>\s*opt\.max_watchdog_steps:",
            "watchdog_steps>=opt.max_watchdog_steps:  # V64_NATIVE_WATCHDOG_EXHAUSTION_TIMING",
            old,
            count=1,
        )

    backup = path.with_name(path.name + ".pre_v64_watchdog_timing.bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    txt = txt[:m.start()] + new + txt[m.end():]
    path.write_text(txt)
    py_compile.compile(str(path), doraise=True)
    print(f"Installed v64 native watchdog timing patch: {path}")
    print(f"Backup: {backup}")
    return True


def restore(path: Path) -> None:
    backup = path.with_name(path.name + ".pre_v64_watchdog_timing.bak")
    if not backup.exists():
        raise RuntimeError(f"No v64 backup exists: {backup}")
    shutil.copy2(backup, path)
    py_compile.compile(str(path), doraise=True)
    print(f"Restored pre-v64 solver: {path}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--solver-path", default="")
    ap.add_argument("--restore", action="store_true")
    a = ap.parse_args()
    p = Path(a.solver_path).resolve() if a.solver_path else solver_path()
    restore(p) if a.restore else apply_patch(p)


if __name__ == "__main__":
    main()
