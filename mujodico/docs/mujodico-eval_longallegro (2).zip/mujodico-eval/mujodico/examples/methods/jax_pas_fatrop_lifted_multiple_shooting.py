"""JAX/PAS FATROP method exposed through the examples runner."""

import time

import jax
import numpy as np

from mujodico.examples.methods import support
from mujodico.examples.tasks import Task
from mujodico import mjx
from mujodico.trajopt._src.fatrop_ref import FatropRefOptions


class JaxPasFatropLiftedMultipleShooting:
  """Lifted contact FATROP using the JAX PAS linear-system backend.

  The lifted problem is shared with the official FATROP benchmark so this
  method has the same contact-force variables and inequality ordering.
  """

  def __init__(
      self,
      task: Task,
      contact_approx: mjx.ContactApproxType,
      hess_approx: support.HessianApproxType,
  ):
    try:
      # This module is kept at the repository root because the benchmark
      # scripts also use it as their shared problem definition.
      from benchmark_fatrop_reference_contact import ContactProblem
    except ImportError as exc:
      raise ImportError(
          'JAX PAS FATROP examples require benchmark_fatrop_reference_contact.py '
          'to be importable from the repository root.'
      ) from exc

    if hess_approx == support.HessianApproxType.GaussNewton:
      hessian_mode = 'cost'
    elif hess_approx == support.HessianApproxType.Full:
      hessian_mode = 'exact_lagrangian'
    else:
      raise NotImplementedError(
          'JAX PAS FATROP does not implement the LBFGS Hessian option.'
      )

    self.task = task
    self.problem = ContactProblem(task, contact_approx=contact_approx)
    self.hessian_mode = hessian_mode

  def solve(
      self,
      *,
      xs_init: np.ndarray,
      us_init: np.ndarray,
      iterations: int,
      stagewise: bool = False,
      gpu_line_search: bool = False,
      max_soc: int = 4,
      **kwargs,
  ):
    options = FatropRefOptions(
        max_iter=iterations,
        linear_backend='pas',
        hessian_mode=self.hessian_mode,
        # Match benchmark_fatrop_v64_one.py's ordinary-filter default.  The
        # watchdog remains available through the lower-level API.
        enable_watchdog=False,
        max_soc=max_soc,
        use_gpu_line_search=gpu_line_search,
        **kwargs,
    )

    tic = time.perf_counter()
    result = self.problem.ref.solve(
        xs_init, np.concatenate([
            us_init,
            np.zeros((self.task.horizon, self.problem.ncf), dtype=us_init.dtype),
        ], axis=1), options,
        stagewise=stagewise,
    )
    jax.block_until_ready(result.x)
    total_time = time.perf_counter() - tic

    print(f'''
Method: {self.__class__.__name__}
  total time: {total_time:.6f} sec
  solver status: {result.status}
  accepted steps: {result.accepted_steps}
''')

    return np.asarray(result.x), np.asarray(result.u[:, :self.task.nu])
