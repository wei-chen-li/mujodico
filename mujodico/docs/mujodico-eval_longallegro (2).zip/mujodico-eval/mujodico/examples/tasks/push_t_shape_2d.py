import mujoco
from mujodico.examples.tasks.task import Task
from mujodico.examples.tasks import plotly_util
import numpy as np
import plotly.graph_objects as go
import viser


_XML = """
<mujoco model="push_t_shape_2d">

  <option timestep="0.03" />
  <option integrator="implicitfast" />
  <option iterations="20" tolerance="1e-5" />

  <default>
    <joint damping="5" />
    <geom condim="1" />
  </default>

  <worldbody>

    <body name="pusher" pos="0 0 0">
      <joint name="pusher_slide_x" type="slide" axis="1 0 0" range="-1 1" />
      <joint name="pusher_slide_y" type="slide" axis="0 1 0" range="-1 1" />

      <geom name="pusher_geom"
            type="sphere"
            size="0.035"
            mass="1"
            rgba="1 0 0 1" />
    </body>

    <body name="object" pos="0 0 0">
      <joint name="object_slide_x" type="slide" axis="1 0 0" range="-1 1" />
      <joint name="object_slide_y" type="slide" axis="0 1 0" range="-1 1" />
      <joint name="object_rotate" type="hinge" damping="0.4" />

      <!-- The two overlapping boxes form a single rigid T-shaped object. -->
      <geom name="top_bar"
            type="box"
            pos="0 0.10 0"
            size="0.16 0.04 0.05"
            mass="0.8"
            rgba="0 0 1 1" />
      <geom name="stem"
            type="box"
            pos="0 -0.06 0"
            size="0.04 0.12 0.05"
            mass="0.6"
            rgba="0 0 1 1" />
    </body>

  </worldbody>

  <actuator>
    <velocity name="pusher_vel_x" joint="pusher_slide_x" kv="20" ctrlrange="-0.5 0.5" />
    <velocity name="pusher_vel_y" joint="pusher_slide_y" kv="20" ctrlrange="-0.5 0.5" />
  </actuator>

</mujoco>
"""


class PushTShape2d(Task):

  def __init__(
      self,
      seed=0,
      mass_scale=0.5,
      damping=10.0,
      timestep=0.03,
  ):
    model = mujoco.MjModel.from_xml_string(_XML)
    model.opt.timestep = timestep

    # Keep the hinge damping from the XML while exposing the common slide
    # damping as a search parameter.
    for joint_name in (
        'pusher_slide_x', 'pusher_slide_y',
        'object_slide_x', 'object_slide_y',
    ):
      joint_id = mujoco.mj_name2id(
          model, mujoco.mjtObj.mjOBJ_JOINT, joint_name
      )
      model.dof_damping[model.jnt_dofadr[joint_id]] = damping

    # Scale mass and inertia together so the rigid bodies keep the same shape
    # and mass distribution throughout the parameter search.
    for body_name in ('pusher', 'object'):
      body_id = mujoco.mj_name2id(
          model, mujoco.mjtObj.mjOBJ_BODY, body_name
      )
      model.body_mass[body_id] *= mass_scale
      model.body_inertia[body_id] *= mass_scale

    horizon = 100

    rng = np.random.default_rng(seed)

    object_x, object_theta = rng.uniform(
        [-0.15, -2 * np.pi / 3], [0.15, 2 * np.pi / 3]
    )
    object_y = -0.15
    # Place the pusher just below the stem in the T's local frame.  Rotating
    # this offset with the object preserves a useful pushing contact for all
    # initial object orientations.
    pusher_offset = np.array([
        -0.03 * np.sign(object_theta), -0.22
    ])
    c, s = np.cos(object_theta), np.sin(object_theta)
    pusher_x = object_x + pusher_offset[0] * c - pusher_offset[1] * s
    pusher_y = object_y + pusher_offset[0] * s + pusher_offset[1] * c
    x_0 = np.concatenate((
        [pusher_x, pusher_y],
        [object_x, object_y, object_theta],
        [0.0] * 5,
    ))
    x_goal = np.array([0.0, 0.0, 0.0, 0.0, 0.0] + [0.0] * 5)
    Q = np.diag([
        0.0, 0.0,
        4.0, 4.0, 0.5,
        0.0, 0.0, 0.01, 0.01, 0.002,
    ])
    Qf = Q * 200.0

    u_ref = np.array([0.0, 0.0])
    R = np.eye(2) * 0.01

    contact_smoothing = 0.02

    super().__init__(
        model=model,
        horizon=horizon,
        x_0=x_0,
        x_goal=x_goal,
        Q=Q,
        Qf=Qf,
        u_ref=u_ref,
        R=R,
        contact_smoothing=contact_smoothing,
    )

  def _update_visualization(
      self, server: viser.ViserServer, k: int, xs: np.ndarray
  ):
    fig = go.Figure()
    plotly_util.add_line(
        fig=fig, x=xs[:k+1, 0], y=xs[:k+1, 1], name='Pusher', color='red'
    )
    plotly_util.add_circle(
        fig=fig, x=xs[k, 0], y=xs[k, 1], r=0.035, color='red'
    )
    plotly_util.add_line(
        fig=fig, x=xs[:k+1, 2], y=xs[:k+1, 3], name='Object', color='blue'
    )
    self._add_t_shape(fig, xs[k, 2], xs[k, 3], xs[k, 4], 'Object', 1.0)
    self._add_t_shape(
        fig, self.x_goal[2], self.x_goal[3], self.x_goal[4],
        'Object goal', 0.2,
    )
    fig.update_layout(
        xaxis_title='x', yaxis_title='y',
        xaxis={'range': [-0.5, 0.5]},
        yaxis={'range': [-0.5, 0.5], 'scaleanchor': 'x', 'scaleratio': 1},
    )
    if not hasattr(self, 'plot'):
      server.scene.add_grid('grid')
      self.plot = server.gui.add_plotly(fig)
    else:
      self.plot.figure = fig

  @staticmethod
  def _add_t_shape(fig, x, y, theta, name, opacity):
    for dx, dy, w, h in ((0.0, 0.10, 0.32, 0.08), (0.0, -0.06, 0.08, 0.24)):
      c, s = np.cos(theta), np.sin(theta)
      fig_x = x + dx * c - dy * s
      fig_y = y + dx * s + dy * c
      plotly_util.add_rectangle(
          fig=fig, x=fig_x, y=fig_y, theta=theta, w=w, h=h,
          name=name, color='blue', opacity=opacity,
      )


if __name__ == '__main__':
  task = PushTShape2d()
  task.print_summary()
