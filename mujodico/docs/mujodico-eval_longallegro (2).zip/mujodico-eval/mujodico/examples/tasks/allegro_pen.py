from pathlib import Path
import tempfile
import mujoco
from mujodico.examples.tasks.task import Task
from mujodico.examples.tasks import plotly_util
import numpy as np
import plotly.graph_objects as go
import plotly.subplots
import viser


_XML = """
<mujoco model="right_allegro_hand scene">

  <option timestep="0.02"  />
  <option integrator="implicitfast" />
  <option iterations="40" tolerance="1e-6" />

  <include file="right_hand2.xml"/>

  <worldbody>
    <body name="object" pos="-0.025 0 0.026">
      <joint name="object_joint" type="free" damping="0.05" armature="0.002"/>
      <geom type="capsule" size="0.015" fromto="0 -0.08 0 0 0.08 0" rgba="0.5 0.7 0.5 1"
            friction="0.7" density="600" solref="0.02 1" solimp="0.9 0.95 0.001"/>
      <geom name="angle_indicator" type="sphere" size="0.005" pos="0 0 0.011" rgba="0 0 0 1"
            contype="0" conaffinity="0" />
    </body>
  </worldbody>

</mujoco>
"""


class AllegroPen(Task):

  # Collision variants are generated from the simplified geometry in
  # right_hand2.xml.  The mesh variant is retained for comparison; the
  # inflated variant is the cheaper approximation for normal use.
  mesh_collision = False
  inflated_collision = False

  def __init__(self, seed=0, goal_option=3):
    dir = Path(__file__).resolve().parent
    allegro_xml_path = dir / 'models' / 'wonik_allegro' / 'right_hand2.xml'

    hand_include_name = allegro_xml_path.name
    hand_scene_path = None
    if self.mesh_collision or self.inflated_collision:
      hand_xml = allegro_xml_path.read_text()
      if self.mesh_collision:
        hand_xml = hand_xml.replace(
            '<geom type="mesh" contype="0" conaffinity="0" group="2" material="black"/>',
            '<geom type="mesh" contype="1" conaffinity="1" group="2" material="black"/>',
        )
        hand_xml = hand_xml.replace(
            '<geom group="3" contype="0" conaffinity="1"',
            '<geom group="3" contype="0" conaffinity="0"',
        )
      if self.inflated_collision:
        # Enlarge the primitive collision shapes by about 15--20% so their
        # contact envelope covers the visible hand meshes.
        inflated_sizes = {
            'size="0.0204"': 'size="0.024"',
            'size="0.0098 0.01375 0.0082"': 'size="0.0115 0.016 0.0095"',
            'size="0.0179 0.017 0.02275"': 'size="0.021 0.020 0.026"',
            'size="0.012 0.015"': 'size="0.014 0.018"',
            'size="0.012 0.01"': 'size="0.014 0.012"',
            'size="0.012 0.007"': 'size="0.014 0.0085"',
            'size="0.012 0.012"': 'size="0.014 0.014"',
            'size="0.0098 0.01375 0.008"': 'size="0.0115 0.016 0.0095"',
            'size="0.0098 0.01375 0.0157"': 'size="0.0115 0.016 0.018"',
            'size="0.012 0.009"': 'size="0.014 0.011"',
            'size="0.012 0.010"': 'size="0.014 0.012"',
        }
        for old, new in inflated_sizes.items():
          hand_xml = hand_xml.replace(old, new)
      with tempfile.NamedTemporaryFile(
          mode='w',
          suffix='.xml',
          prefix='right_hand2_collision_variant_',
          dir=allegro_xml_path.parent,
          delete=False,
      ) as f:
        f.write(hand_xml)
      hand_scene_path = Path(f.name)
      hand_include_name = hand_scene_path.name

    scene_xml = _XML.replace('right_hand2.xml', hand_include_name)

    with tempfile.NamedTemporaryFile(
        mode='w',
        suffix='.xml',
        dir=allegro_xml_path.parent,
        delete=False,
    ) as f:
      f.write(scene_xml)

    scene_path = f.name
    try:
      model = mujoco.MjModel.from_xml_path(scene_path)
    finally:
      Path(scene_path).unlink()
      if hand_scene_path is not None:
        hand_scene_path.unlink()
    data = mujoco.MjData(model)

    horizon = 250#15

    x_0 = np.concatenate((data.qpos, data.qvel))
    x_0[0:4] = np.deg2rad([0, 70, 80, 60])
    x_0[4:8] = np.deg2rad([0, 40, 60, 30])
    x_0[8:12] = np.deg2rad([0, 70, 80, 60])
    x_0[12:16] = np.deg2rad([50, 110, 80, 60])

    # Primary pose: upright between the index and middle fingertips.
    primary_pos = np.array([0.026, -0.022, 0.100])
    q_upright = np.array([
        np.cos(np.deg2rad(90) / 2),
        np.sin(np.deg2rad(90) / 2),
        0.0,
        0.0,
    ])

    x_goal_primary = x_0.copy()
    x_goal_primary[16:19] = primary_pos
    x_goal_primary[19:23] = q_upright

    # Secondary pose: move to the gap between the index (ff) and ring (rf)
    # fingertips, slide halfway down toward the fingertip plane, then rotate
    # 90 degrees about the world z-axis (the palm-normal axis).  The pen is
    # still upright in this pose.
    secondary_pos = np.array([0.000, 0.000, 0.085])
    q_z90 = np.array([
        np.cos(np.deg2rad(90) / 2),
        0.0,
        0.0,
        np.sin(np.deg2rad(90) / 2),
    ])
    # q_z90 * q_upright: apply the z rotation in world coordinates.
    q_secondary = np.array([0.5, 0.5, 0.5, 0.5])

    x_goal_secondary = x_goal_primary.copy()
    x_goal_secondary[16:19] = secondary_pos
    x_goal_secondary[19:23] = q_secondary

    # Third pose: while sliding down, bring the pen back into the palm plane,
    # then move its center of mass 5 cm in +x, away from the palm.  The pen
    # remains parallel to the palm in its original local-y orientation.
    x_goal_third = x_goal_secondary.copy()
    x_goal_third[16:19] = secondary_pos + np.array([0.050, 0.0, 0.0])
    x_goal_third[19:23] = np.array([1.0, 0.0, 0.0, 0.0])

    goal_options = {
        1: x_goal_primary,
        2: x_goal_secondary,
        3: x_goal_third,
    }
    if goal_option not in goal_options:
      raise ValueError(f'goal_option must be one of {tuple(goal_options)}')

    # Keep all poses available for staged planning while selecting one as the
    # task's active terminal goal.
    x_goal = goal_options[goal_option]

    quaternion_starts = (19,)

    Q = np.diag([0.0] * 16 + [100] * 3 + [0.01] * 4 + [0.0] * 22)
    Qf = Q * 40.0

    u_ref = x_0[:16]
    R = np.eye(16) * 0.01

    contact_smoothing = 0.002

    super().__init__(
        model=model,
        horizon=horizon,
        x_0=x_0,
        x_goal=x_goal,
        Q=Q,
        Qf=Qf,
        u_ref=u_ref,
        R=R,
        contact_smoothing=contact_smoothing,
        quaternion_starts=quaternion_starts,
    )
    self.x_goal_primary = x_goal_primary
    self.x_goal_secondary = x_goal_secondary
    self.x_goal_third = x_goal_third


class AllegroPenMeshCollision(AllegroPen):
  """Allegro pen task using the hand meshes for collision detection."""

  mesh_collision = True


class AllegroPenInflatedCollision(AllegroPen):
  """Allegro pen task using inflated primitive hand collision shapes."""

  inflated_collision = True

  def _plot_object_dof(self, fig: go.Figure, k: int, xs: np.ndarray, object_dof: int):
    ts = np.arange(xs.shape[0]) * self.model.opt.timestep
    t_range = [min(ts), max(ts)]

    dof = 16 + object_dof
    if object_dof < 3:
      values = xs[:, dof]
      goal = self.x_goal[dof]
    else:
      values = 1.0 - (xs[:, dof:dof+4] @ self.x_goal[dof:dof+4])**2
      goal = 0.0

    y_min = min(np.min(values), goal)
    y_max = max(np.max(values), goal)
    y_pad = max(y_max - y_min, 1e-5) * 0.05
    y_range = [y_min - y_pad, y_max + y_pad]

    plotly_util.add_line(
        fig=fig,
        x=ts[:k+1],
        y=values[:k+1],
        color='blue',
        row=object_dof + 1,
        col=1,
    )
    plotly_util.add_line(
        fig=fig,
        x=t_range,
        y=[goal, goal],
        color='black',
        linestyle='dash',
        row=object_dof + 1,
        col=1,
    )
    fig.update_xaxes(
        title_text='Time (sec)' if object_dof == 3 else None,
        range=t_range,
        row=object_dof + 1,
        col=1,
    )
    fig.update_yaxes(
        title_text=['X Position (m)', 'Y Position (m)', 'Z Position (m)', 'Quaternion error'][object_dof],
        range=y_range,
        row=object_dof + 1,
        col=1,
    )

  def _update_visualization(
      self, server: viser.ViserServer, k: int, xs: np.ndarray
  ):
    fig = plotly.subplots.make_subplots(
        rows=4, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.02,
    )
    for object_dof in (0, 1, 2, 3):
      self._plot_object_dof(fig, k, xs, object_dof)

    if not hasattr(self, 'plot'):
      server.scene.add_grid('grid')
      self.plot = server.gui.add_plotly(fig, aspect=1.5)
    else:
      self.plot.figure = fig


if __name__ == '__main__':
  task = AllegroPen()
  task.print_summary()

  import mjviser
  model = task.model
  server = viser.ViserServer()
  scene = mjviser.ViserMujocoScene(server, model, num_envs=1)
  scene.camera_tracking_enabled = False

  data = mujoco.MjData(model)
  data.qpos = task.x_0[:model.nq]
  mujoco.mj_kinematics(model, data)
  scene.update_from_mjdata(data)
  server.sleep_forever()
