import os
import time
import csv
from pathlib import Path

from absl import app
from absl import flags
import jax
from jax import numpy as jp
import mujoco
from mujodico import mjx
from mujodico.examples.methods import get_method_names, parse_method_name, support
from mujodico.examples.tasks import get_task_names, parse_task_name
import numpy as np


_METHOD = flags.DEFINE_string(
    'method',
    None,
    f'<{"|".join(get_method_names())}>\n(required)',
    required=True,
)
_TASK = flags.DEFINE_string(
    'task',
    None,
    f'<{"|".join(get_task_names())}>\n(required)',
    required=True,
)
_CONTACT_APPROX = flags.DEFINE_string(
    'contact_approx',
    None,
    f'<{"|".join([t.value for t in mjx.ContactApproxType])}>:'
    ' Contact approximation for planning.\n(required)',
    required=True,
)
_HESS_APPROX = flags.DEFINE_string(
    'hess_approx',
    'gaussnewton',
    f'<{"|".join([t.value for t in support.HessianApproxType])}>:'
    ' Trajectory optimization Hessian approximation.'
)
_ITERATIONS = flags.DEFINE_integer(
    'iterations', 500, 'Number of solver iterations', lower_bound=0,
)
_TESTS = flags.DEFINE_integer(
    'tests', 1, 'Number of test cases to run.', lower_bound=1,
)
_SEED = flags.DEFINE_integer(
    'seed', 0, 'Random seed for tests.',
)
_K = flags.DEFINE_integer(
    'k', 2,
    'Initial revolution-band lower bound for PushSquareKnobHorizonScaling.',
    lower_bound=1,
)
_GOAL_OPTION = flags.DEFINE_integer(
    'goal_option', 3,
    'AllegroPen terminal goal: 1=primary, 2=secondary, 3=third.',
    lower_bound=1,
    upper_bound=3,
)
_WARMUP = flags.DEFINE_integer(
    'warmup', 0,
    'Number of un-timed warmup solves per test (compiles JAX kernels first).',
    lower_bound=0,
)
_JAX_CACHE = flags.DEFINE_string(
    'jax_cache', '',
    'Persistent JAX compilation cache directory. Empty disables explicit setup.',
)
_SAVE_TRAJECTORY = flags.DEFINE_string(
    'save_trajectory',
    '',
    'Write the solved trajectory and task metadata to a compressed .npz file.',
)
_STAGEWISE = flags.DEFINE_enum(
    'stagewise', 'auto', ['auto', 'true', 'false'],
    'Stagewise derivative evaluation: auto selects CPU=true, GPU=false.',
)
_GPU_LINE_SEARCH = flags.DEFINE_bool(
    'gpu_line_search', False,
    'Run ordinary filter backtracking on the GPU (disables SOC corrections).',
)
_MAX_SOC = flags.DEFINE_integer(
    'max_soc', 4, 'Maximum second-order correction attempts.', lower_bound=0,
)
_PRINT_LEVEL = flags.DEFINE_integer(
    'print_level', 0, 'FATROP solver print level.', lower_bound=0,
)


def _main(argv) -> None:
  if len(argv) > 1:
    raise app.UsageError('Too many command-line arguments.')

  if _JAX_CACHE.value:
    # JAX is imported above, but its compilation cache can still be configured
    # before any of the method kernels are compiled.
    os.makedirs(_JAX_CACHE.value, exist_ok=True)
    try:
      jax.config.update('jax_compilation_cache_dir', _JAX_CACHE.value)
      jax.config.update('jax_persistent_cache_min_compile_time_secs', 0)
      jax.config.update('jax_persistent_cache_min_entry_size_bytes', -1)
    except Exception as exc:  # Older JAX versions may lack these settings.
      print(f'Warning: could not configure JAX compilation cache: {exc}')

  method_cls = parse_method_name(_METHOD.value)
  task_cls = parse_task_name(_TASK.value)

  contact_approx = mjx.ContactApproxType._resolve(_CONTACT_APPROX.value)

  hess_approx = support.HessianApproxType._resolve(_HESS_APPROX.value)

  result_dir = Path(__file__).resolve().parent / 'result'
  result_dir.mkdir(exist_ok=True)
  result_file = result_dir / f'{task_cls.__name__}_{contact_approx.value}_{method_cls.__name__}.csv'
  print(result_file)

  with open(result_file, 'a', newline='') as f:
    writer = csv.writer(f)
    if f.tell() == 0:
      writer.writerow(['seed', 'goal_error', 'solve_time_sec', 'solver_iters'])

    for seed in range(_SEED.value, _SEED.value + _TESTS.value):
      if task_cls.__name__ == 'PushSquareKnobHorizonScaling':
        task = task_cls(seed, k=_K.value)
      elif task_cls.__name__ in (
          'AllegroPen',
          'AllegroPenMeshCollision',
          'AllegroPenInflatedCollision',
      ):
        task = task_cls(seed, goal_option=_GOAL_OPTION.value)
      else:
        task = task_cls(seed)
      method = method_cls(task, contact_approx, hess_approx)
      iters = _ITERATIONS.value

      method_kwargs = {}
      if method_cls.__name__ == 'JaxPasFatropLiftedMultipleShooting':
        if _STAGEWISE.value == 'auto':
          stagewise = os.environ.get('JAX_PLATFORMS', '').lower() == 'cpu'
        else:
          stagewise = _STAGEWISE.value == 'true'
        method_kwargs = {
            'stagewise': stagewise,
            'gpu_line_search': _GPU_LINE_SEARCH.value,
            'max_soc': 0 if _GPU_LINE_SEARCH.value else _MAX_SOC.value,
            'print_level': _PRINT_LEVEL.value,
        }

      for _ in range(_WARMUP.value):
        method.solve(
            xs_init=task.xs_init,
            us_init=task.us_init,
            iterations=iters,
            **method_kwargs,
        )

      tic = time.perf_counter()
      xs_nominal, us_nominal = method.solve(
          xs_init=task.xs_init,
          us_init=task.us_init,
          iterations=iters,
          **method_kwargs,
      )
      solve_time = time.perf_counter() - tic

      goal_error = support.state_cost(
          task.Q, task.x_goal, xs_nominal[-1], task.quaternion_starts
      )

      writer.writerow([seed, goal_error, solve_time, iters])
      f.flush()

      if _SAVE_TRAJECTORY.value:
        save_path = Path(_SAVE_TRAJECTORY.value)
        if _TESTS.value > 1:
          save_path = save_path.with_name(
              f'{save_path.stem}_seed{seed}{save_path.suffix}'
          )
        save_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            save_path,
            xs=np.asarray(xs_nominal),
            us=np.asarray(us_nominal),
            x_0=np.asarray(task.x_0),
            x_goal=np.asarray(task.x_goal),
            timestep=np.asarray(task.model.opt.timestep),
            goal_error=np.asarray(goal_error),
            seed=np.asarray(seed),
            horizon=np.asarray(task.horizon),
            task=np.asarray(task_cls.__name__),
        )
        print(f'  trajectory: {save_path}')

      print(f'''
  Task: {task_cls.__name__}
  Method: {method_cls.__name__}
    seed: {seed}
    goal error: {goal_error:.8f}
    solve time: {solve_time:.4f} sec
    iterations: {iters}
  ''')

  if _TESTS.value == 1:
    task.visualize_trajectory(xs_nominal)


def main():
  app.run(_main)


if __name__ == '__main__':
  main()
