"""Local parameter grid search for PushTShape2d with lifted IPOPT.

Example:

  JAX_PLATFORMS=cpu python grid_search_push_t_shape_2d.py \
      --iterations 100 --num-seeds 3 --output /tmp/push_t_grid.csv

The defaults search a local 3^6 grid around the current T task settings:
mass, damping, timestep, position Q, rotation Q, and velocity Q scale.
"""

import argparse
import csv
import itertools
import multiprocessing
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np

from mujodico import mjx
from mujodico.examples.methods import support
from mujodico.examples.methods.ipopt_lifted_multiple_shooting import (
    IpoptLiftedMultipleShooting,
)
from mujodico.examples.tasks.push_t_shape_2d import PushTShape2d
from mujodico.examples.tasks.task import Task


def _float_list(value: str) -> list[float]:
  try:
    values = [float(item.strip()) for item in value.split(',') if item.strip()]
  except ValueError as exc:
    raise argparse.ArgumentTypeError(
        f'expected comma separated numbers, got {value!r}'
    ) from exc
  if not values:
    raise argparse.ArgumentTypeError('list must contain at least one number')
  return values


def make_task(
    seed: int,
    mass_scale: float,
    damping: float,
    timestep: float,
    q_position: float,
    q_theta: float,
    q_velocity_scale: float,
    qf_scale: float,
) -> Task:
  base = PushTShape2d(
      seed,
      mass_scale=mass_scale,
      damping=damping,
      timestep=timestep,
  )
  q = base.Q.copy()
  q[2, 2] = q_position
  q[3, 3] = q_position
  q[4, 4] = q_theta
  q[7, 7] = 0.01 * q_velocity_scale
  q[8, 8] = 0.01 * q_velocity_scale
  q[9, 9] = 0.002 * q_velocity_scale

  return Task(
      model=base.model,
      horizon=base.horizon,
      x_0=base.x_0,
      x_goal=base.x_goal,
      Q=q,
      Qf=q * qf_scale,
      u_ref=base.u_ref,
      R=base.R,
      contact_smoothing=base.contact_smoothing,
      quaternion_starts=base.quaternion_starts,
  )


def goal_error(task: Task, x_final: np.ndarray) -> float:
  dx = np.asarray(x_final) - task.x_goal
  return float(np.sqrt(np.sum(np.diag(task.Qf) * dx * dx)))


def run_one(values: tuple) -> dict:
  """Run one independent seed/parameter combination in a worker process."""
  (
      seed, mass_scale, damping, timestep, q_position, q_theta,
      q_velocity_scale, qf_scale, iterations,
  ) = values
  row = {
      'seed': seed,
      'mass_scale': mass_scale,
      'damping': damping,
      'timestep': timestep,
      'q_position': q_position,
      'q_theta': q_theta,
      'q_velocity_scale': q_velocity_scale,
      'qf_scale': qf_scale,
      'iterations': iterations,
  }
  try:
    task = make_task(
        seed, mass_scale, damping, timestep, q_position, q_theta,
        q_velocity_scale, qf_scale,
    )
    method = IpoptLiftedMultipleShooting(
        task,
        mjx.ContactApproxType.HUNT_CROSSLEY,
        support.HessianApproxType.GaussNewton,
    )
    tic = time.perf_counter()
    xs, _ = method.solve(
        xs_init=task.xs_init,
        us_init=task.us_init,
        iterations=iterations,
    )
    row['solve_time_sec'] = time.perf_counter() - tic
    row['goal_error'] = goal_error(task, xs[-1])
    row['error'] = ''
  except Exception as exc:  # Keep the remaining grid running.
    row['solve_time_sec'] = ''
    row['goal_error'] = ''
    row['error'] = f'{type(exc).__name__}: {exc}'
  return row


def main() -> None:
  parser = argparse.ArgumentParser(description=__doc__)
  parser.add_argument('--mass-scales', type=_float_list, default=[0.4, 0.5, 0.6])
  parser.add_argument('--damping-values', type=_float_list, default=[8.0, 10.0, 12.0])
  parser.add_argument('--timesteps', type=_float_list, default=[0.025, 0.03, 0.035])
  parser.add_argument('--q-position-values', type=_float_list, default=[3.0, 4.0, 5.0])
  parser.add_argument('--q-theta-values', type=_float_list, default=[0.25, 0.5, 1.0])
  parser.add_argument('--q-velocity-scales', type=_float_list, default=[0.5, 1.0, 2.0])
  parser.add_argument('--qf-scale', type=float, default=200.0)
  parser.add_argument('--iterations', type=int, default=100)
  parser.add_argument(
      '--workers', type=int, default=1,
      help='Parallel worker processes. 1 disables parallelism.',
  )
  parser.add_argument('--seed-start', type=int, default=0)
  parser.add_argument('--num-seeds', type=int, default=1)
  parser.add_argument('--output', type=Path, default=Path('push_t_shape_grid.csv'))
  args = parser.parse_args()

  if args.iterations < 0 or args.num_seeds < 1 or args.workers < 1:
    parser.error(
        '--iterations and --workers must be nonnegative/positive, '
        'and --num-seeds must be positive'
    )

  combinations = list(itertools.product(
      args.mass_scales,
      args.damping_values,
      args.timesteps,
      args.q_position_values,
      args.q_theta_values,
      args.q_velocity_scales,
  ))
  args.output.parent.mkdir(parents=True, exist_ok=True)
  fields = [
      'seed', 'mass_scale', 'damping', 'timestep', 'q_position', 'q_theta',
      'q_velocity_scale', 'qf_scale', 'iterations', 'goal_error',
      'solve_time_sec', 'error',
  ]

  with args.output.open('w', newline='') as output_file:
    writer = csv.DictWriter(output_file, fieldnames=fields)
    writer.writeheader()
    total = len(combinations) * args.num_seeds
    completed = 0
    print(f'running {total} solves across {len(combinations)} configurations')

    jobs = [
        (seed, *values, args.qf_scale, args.iterations)
        for seed in range(args.seed_start, args.seed_start + args.num_seeds)
        for values in combinations
    ]
    worker_count = min(args.workers, total)
    context = multiprocessing.get_context('spawn')
    with ProcessPoolExecutor(
        max_workers=worker_count, mp_context=context,
    ) as executor:
      for row in executor.map(run_one, jobs):
        writer.writerow(row)
        output_file.flush()
        completed += 1
        print(
            f'[{completed}/{total}] seed={row["seed"]} '
            f'values=({row["mass_scale"]}, {row["damping"]}, '
            f'{row["timestep"]}, {row["q_position"]}, '
            f'{row["q_theta"]}, {row["q_velocity_scale"]}) '
            f'goal_error={row["goal_error"]}',
            flush=True,
        )


if __name__ == '__main__':
  main()
