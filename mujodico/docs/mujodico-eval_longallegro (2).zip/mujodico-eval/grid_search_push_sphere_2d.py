"""Grid search task and cost parameters for PushSphere2d.

Example (run on CPU):

  JAX_PLATFORMS=cpu python grid_search_push_sphere_2d.py \
      --iterations 100 --num-seeds 10 \
      --output /tmp/push_sphere_grid.csv

The default grid has 3 mass values, 3 damping values, 3 timesteps, and
3 position and velocity Q values, for 243 task/weight combinations per seed.
"""

import argparse
import csv
import itertools
import time
from pathlib import Path

import mujoco
import numpy as np

from mujodico import mjx
from mujodico.examples.methods import support
from mujodico.examples.methods.ipopt_lifted_multiple_shooting import (
    IpoptLiftedMultipleShooting,
)
from mujodico.examples.tasks.push_sphere_2d import PushSphere2d
from mujodico.examples.tasks.task import Task


def _float_list(value: str) -> list[float]:
  try:
    values = [float(item.strip()) for item in value.split(',') if item.strip()]
  except ValueError as exc:
    raise argparse.ArgumentTypeError(
        f'expected comma separated numbers, got {value!r}'
    ) from exc
  if not values:
    raise argparse.ArgumentTypeError('list must contain at least one number')
  return values


def _configure_task(
    seed: int,
    mass_scale: float,
    damping: float,
    timestep: float,
    q_position: float,
    q_velocity: float,
    qf_scale: float,
) -> Task:
  base = PushSphere2d(seed)
  model = base.model
  model.opt.timestep = timestep

  # PushSphere2d has only slide joints, so one damping value applies to every
  # degree of freedom in this task.
  model.dof_damping[:] = damping

  # Scale mass and inertia together to preserve the body's mass distribution.
  for body_name in ('pusher', 'object'):
    body_id = mujoco.mj_name2id(
        model, mujoco.mjtObj.mjOBJ_BODY, body_name
    )
    model.body_mass[body_id] *= mass_scale
    model.body_inertia[body_id] *= mass_scale

  q = base.Q.copy()
  q[2, 2] = q_position
  q[3, 3] = q_position
  q[6, 6] = q_velocity
  q[7, 7] = q_velocity

  return Task(
      model=model,
      horizon=base.horizon,
      x_0=base.x_0,
      x_goal=base.x_goal,
      Q=q,
      Qf=q * qf_scale,
      u_ref=base.u_ref,
      R=base.R,
      contact_smoothing=base.contact_smoothing,
      quaternion_starts=base.quaternion_starts,
  )


def _goal_error(task: PushSphere2d, x_final: np.ndarray) -> float:
  dx = np.asarray(x_final) - task.x_goal
  return float(np.sqrt(np.sum(np.diag(task.Qf) * dx * dx)))


def main() -> None:
  parser = argparse.ArgumentParser(description=__doc__)
  parser.add_argument('--mass-scales', type=_float_list, default=[0.5, 1.0, 2.0])
  parser.add_argument('--damping-values', type=_float_list, default=[2.0, 5.0, 10.0])
  parser.add_argument('--timesteps', type=_float_list, default=[0.01, 0.02, 0.03])
  parser.add_argument('--q-position-values', type=_float_list, default=[0.5, 1.0, 2.0])
  parser.add_argument('--q-velocity-values', type=_float_list, default=[0.01, 0.1, 1.0])
  parser.add_argument('--qf-scale', type=float, default=100.0)
  parser.add_argument('--iterations', type=int, default=100)
  parser.add_argument('--seed-start', type=int, default=0)
  parser.add_argument('--num-seeds', type=int, default=1)
  parser.add_argument('--output', type=Path, default=Path('push_sphere_grid.csv'))
  args = parser.parse_args()

  if args.iterations < 0 or args.num_seeds < 1:
    parser.error('--iterations must be nonnegative and --num-seeds must be positive')

  contact_approx = mjx.ContactApproxType.HUNT_CROSSLEY
  hess_approx = support.HessianApproxType.GaussNewton
  combinations = itertools.product(
      args.mass_scales,
      args.damping_values,
      args.timesteps,
      args.q_position_values,
      args.q_velocity_values,
  )
  combinations = list(combinations)
  args.output.parent.mkdir(parents=True, exist_ok=True)

  fields = [
      'seed', 'mass_scale', 'damping', 'timestep', 'q_position',
      'q_velocity', 'qf_scale', 'iterations', 'goal_error',
      'solve_time_sec', 'error',
  ]
  with args.output.open('w', newline='') as output_file:
    writer = csv.DictWriter(output_file, fieldnames=fields)
    writer.writeheader()

    total = len(combinations) * args.num_seeds
    completed = 0
    print(f'running {total} solves across {len(combinations)} configurations')

    for seed in range(args.seed_start, args.seed_start + args.num_seeds):
      for mass_scale, damping, timestep, q_position, q_velocity in combinations:
        row = {
            'seed': seed,
            'mass_scale': mass_scale,
            'damping': damping,
            'timestep': timestep,
            'q_position': q_position,
            'q_velocity': q_velocity,
            'qf_scale': args.qf_scale,
            'iterations': args.iterations,
        }
        try:
          task = _configure_task(
              seed, mass_scale, damping, timestep,
              q_position, q_velocity, args.qf_scale,
          )
          method = IpoptLiftedMultipleShooting(task, contact_approx, hess_approx)
          tic = time.perf_counter()
          xs, _ = method.solve(
              xs_init=task.xs_init,
              us_init=task.us_init,
              iterations=args.iterations,
          )
          row['solve_time_sec'] = time.perf_counter() - tic
          row['goal_error'] = _goal_error(task, xs[-1])
          row['error'] = ''
        except Exception as exc:  # Keep the grid running after one bad point.
          row['solve_time_sec'] = ''
          row['goal_error'] = ''
          row['error'] = f'{type(exc).__name__}: {exc}'

        writer.writerow(row)
        output_file.flush()
        completed += 1
        print(
            f'[{completed}/{total}] seed={seed} '
            f'mass={mass_scale:g} damping={damping:g} dt={timestep:g} '
            f'qpos={q_position:g} qvel={q_velocity:g} '
            f'error={row["goal_error"]}',
            flush=True,
        )


if __name__ == '__main__':
  main()
