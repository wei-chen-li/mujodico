# FATROP/PAS v64 — watchdog timing fix + five-task quality benchmark

This bundle is intentionally narrow. It does **not** change PAS, SOC, the Newton
KKT, or the validated restoration NLP.

## Fix

The v44 integration inherited

```python
watchdog_steps += 1
if watchdog_steps > opt.max_watchdog_steps:
```

With `max_watchdog_steps=3`, that commits three rejected watchdog iterates before
restoration. The native Fingers trace commits only two (`11w`, `12w`); the third
failed watchdog trial restores the checkpoint and enters restoration (`13r`).

v64 changes only `>` to `>=` in the v44 watchdog-exhaustion branch. Because the
check occurs before the normal outer-row recording, the third failed watchdog
trial becomes the restoration transition rather than an extra `w` row.

Expected first episode:

```text
10  ... h     # checkpoint
11  ... w
12  ... w
V44_RESTORATION_ENTER it=13 ...
12r ...       # restoration module entry row numbering may display previous iter
13r/14r ...   # restoration rows depending on nested counter convention
```

The decisive check is **exactly two committed `w` rows before the first
`V44_RESTORATION_ENTER`**, and restoration entry from the saved checkpoint near
`J ~= 23.14504`, `cv ~= 5.24e-2` on Fingers seed 0.

## Install + smoke + five-task sweep

Unzip/copy this bundle into the MuJoDiCo repository root and run:

```bash
python run_fatrop_v64_finalize_suite.py \
  --outdir fatrop_v64_five_task_quality \
  --smoke-dir fatrop_v64_watchdog_smoke \
  --quality-iters 150 \
  --timeout 1800
```

The runner:

1. preserves your current solver and installs only missing v29/v37/v44 pieces;
2. applies the one-line v64 timing correction;
3. runs Fingers for 20 iterations with JAX serial, JAX PAS, and the **low-level
   FATROP C API cost-Hessian reference**;
4. automatically refuses to launch the long sweep unless the JAX serial log has
   exactly two committed watchdog rows before restoration;
5. runs all five tasks:

```text
PushSphere2d
PushBox2d
PushCircularKnob
PushSquareKnob
FingersSphere2d
```

for

```text
serial-cpu-f64
pas-cpu-f64
official-cpu-f64
```

The quality sweep uses one run/configuration with no warmup so we first establish
robustness/correctness. After that passes, do the repeated warm timing sweep.

## Inspect

```bash
python inspect_fatrop_v64.py \
  fatrop_v64_five_task_quality \
  --smoke-dir fatrop_v64_watchdog_smoke
```

Then send:

```bash
zip -r fatrop_v64_results.zip \
  fatrop_v64_watchdog_smoke \
  fatrop_v64_five_task_quality
```

## Manual commands

Patch only:

```bash
python install_fatrop_v64_stack.py
```

Five-task sweep without re-running the smoke after it has passed:

```bash
python run_fatrop_v64_finalize_suite.py \
  --skip-smoke \
  --quality-iters 150 \
  --timeout 1800 \
  --outdir fatrop_v64_five_task_quality
```

## What is frozen

- PAS/serial generalized Riccati algebra
- SOC recurrence/RHS/total-direction semantics
- v37 paired-elastic restoration KKT
- v43 hard-dynamics restoration correction
- v44 restoration handoff structure

Do not re-open these unless the five-task results produce direct evidence of a
failure in one of them.
