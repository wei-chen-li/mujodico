#!/usr/bin/env python3
"""Apply the v29 exact watchdog rollback/retry patch to installed solver.py.

This patch is intentionally source-local and ABI-agnostic:
- it does not replace solver.py wholesale;
- it leaves _direction/_max_step signatures untouched;
- it preserves compact or expanded dormant-direct-bound state already present;
- it changes only watchdog checkpoint direction storage and rollback retry.

Use:
    python apply_fatrop_v29_watchdog_patch.py

Restore:
    python apply_fatrop_v29_watchdog_patch.py --restore
"""
from __future__ import annotations

import argparse
import py_compile
import re
import shutil
from pathlib import Path


MARKER = "# V29_EXACT_WATCHDOG_RETRY"


def solver_path():
    import mujodico.trajopt._src.fatrop_ref.solver as sm
    return Path(sm.__file__).resolve()


def apply_patch(path: Path):
    txt = path.read_text()

    if MARKER in txt:
        print(f"V29 patch already installed: {path}")
        return False

    # Require the later watchdog implementation that already:
    # - stores a dict checkpoint,
    # - tests only the first watchdog trial,
    # - provisionally accepts a rejected watchdog point.
    required = [
        "watchdog_rejected_trial=True",
        "watchdog_checkpoint['dphi']=dphi",
        "watchdog_steps>opt.max_watchdog_steps",
        "fresh solve from the restored point is equivalent",
    ]
    missing = [q for q in required if q not in txt]
    if missing:
        raise RuntimeError(
            "Installed solver is not the expected pre-v29 watchdog branch. "
            f"Missing markers: {missing}\n"
            f"Solver: {path}\n"
            "Do not patch manually; send the current solver.py instead."
        )

    backup = path.with_name(path.name + ".pre_v29_watchdog.bak")
    if not backup.exists():
        shutil.copy2(path, backup)

    # ------------------------------------------------------------------
    # 1) Store the exact checkpoint Newton direction the first time the
    #    watchdog reference dphi/alpha_test is initialized.
    # ------------------------------------------------------------------
    old_save = """\
            if watchdog_active and watchdog_checkpoint is not None and watchdog_checkpoint['dphi'] is None:
                watchdog_checkpoint['dphi']=dphi
                watchdog_checkpoint['alpha_test']=apmax
"""
    new_save = """\
            if watchdog_active and watchdog_checkpoint is not None and watchdog_checkpoint['dphi'] is None:
                watchdog_checkpoint['dphi']=dphi
                watchdog_checkpoint['alpha_test']=apmax
                # V29_EXACT_WATCHDOG_RETRY
                # Ipopt/FATROP saves the checkpoint search direction.  If the
                # watchdog excursion later fails, ordinary backtracking resumes
                # from this SAME direction rather than solving a new KKT system.
                watchdog_checkpoint['saved_sol']=sol
                watchdog_checkpoint['saved_ds']=ds
                watchdog_checkpoint['saved_dzL']=dzL
                watchdog_checkpoint['saved_dzU']=dzU
                watchdog_checkpoint['saved_apmax']=apmax
                watchdog_checkpoint['saved_admax']=admax
                watchdog_checkpoint['saved_reg']=reg
                # Some installed v9/v16 branches structurally retain dormant
                # direct-bound dual directions.  Preserve them if present, but
                # do not require them.
                if 'dzuL' in locals():
                    watchdog_checkpoint['saved_dzuL']=dzuL
                if 'dzuU' in locals():
                    watchdog_checkpoint['saved_dzuU']=dzuU
                if 'zuL' in locals():
                    watchdog_checkpoint['saved_zuL']=zuL
                if 'zuU' in locals():
                    watchdog_checkpoint['saved_zuU']=zuU
"""
    if old_save not in txt:
        raise RuntimeError("Could not locate checkpoint direction-save block")
    txt = txt.replace(old_save, new_save, 1)

    # ------------------------------------------------------------------
    # 2) Replace only the "restore now; fresh solve next iteration" portion.
    #    Preserve whatever state-restoration lines the installed ABI already
    #    has (including optional zuL/zuU).
    # ------------------------------------------------------------------
    pattern = re.compile(
        r"""(?P<indent>[ ]{24})wb=watchdog_checkpoint\n"""
        r"""(?P=indent)\# Once the watchdog trial budget is exhausted FATROP\n"""
        r"""(?P=indent)\# restores the checkpoint and retries the ordinary line\n"""
        r"""(?P=indent)\# search while skipping the failed first trial\.  The\n"""
        r"""(?P=indent)\# exact same direction is deterministic here, so a\n"""
        r"""(?P=indent)\# fresh solve from the restored point is equivalent; a\n"""
        r"""(?P=indent)\# subsequent iteration performs the retry\.\n"""
        r"""(?P<body>(?:(?P=indent).*\n)+?)"""
        r"""(?P=indent)watchdog_active=False;watchdog_steps=0;watchdog_checkpoint=None;shortened_count=0\n"""
    )

    m = pattern.search(txt)
    if m is None:
        raise RuntimeError(
            "Could not locate the old watchdog rollback block. "
            "The installed source differs from the branch v29 targets."
        )

    indent = m.group("indent")
    body = m.group("body")

    # Keep only the ABI-specific checkpoint restoration statements from the
    # old body, excluding comments/blank lines.
    restore_lines = []
    for line in body.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        restore_lines.append(line)

    restore = "\n".join(restore_lines) + "\n"

    retry = f"""\
{indent}wb=watchdog_checkpoint
{indent}# V29_EXACT_WATCHDOG_RETRY
{indent}# Restore the saved checkpoint state.  The ABI-specific assignments
{indent}# below are retained verbatim from the installed solver.
{restore}\
{indent}# Restore optional dormant direct-bound state if this solver carries it.
{indent}if 'zuL' in locals() and 'saved_zuL' in wb:
{indent}    zuL=wb['saved_zuL']
{indent}if 'zuU' in locals() and 'saved_zuU' in wb:
{indent}    zuU=wb['saved_zuU']
{indent}filt.entries=list(wb['filter_entries'])
{indent}
{indent}# Restore the EXACT direction computed at watchdog entry.  This is the
{indent}# key difference from the pre-v29 implementation.
{indent}sol=wb['saved_sol'];ds=wb['saved_ds']
{indent}dzL=wb['saved_dzL'];dzU=wb['saved_dzU']
{indent}apmax=float(wb['saved_apmax']);admax=float(wb['saved_admax'])
{indent}reg=float(wb['saved_reg'])
{indent}if 'dzuL' in locals() and 'saved_dzuL' in wb:
{indent}    dzuL=wb['saved_dzuL']
{indent}if 'dzuU' in locals() and 'saved_dzuU' in wb:
{indent}    dzuU=wb['saved_dzuU']
{indent}
{indent}# Retry ordinary filter backtracking IN THIS SAME nonlinear iteration.
{indent}# skip_first_trial_point=true means the first retry is gamma_alpha times
{indent}# the saved maximum-feasible watchdog trial.
{indent}watchdog_active=False;watchdog_steps=0;shortened_count=0
{indent}watchdog_rejected_trial=False
{indent}accepted_trial=False;soc_used=False
{indent}th_ref=float(wb['theta']);phi_ref=float(wb['phi'])
{indent}dphi_ref=float(wb['dphi'])
{indent}alpha=apmax*opt.gamma_alpha
{indent}ad=admax
{indent}for retry_lsn in range(2,opt.max_ls+1):
{indent}    xt=(x+alpha*sol.dx).at[0].set(self.x0)
{indent}    ut=u+alpha*sol.du
{indent}    st=s+alpha*ds
{indent}    lamt=lam+alpha*sol.dlambda_dyn
{indent}    betat=beta+alpha*sol.dbeta_eq
{indent}    gammat=gamma+alpha*sol.dgamma_ineq
{indent}    zLt=zL+ad*dzL;zUt=zU+ad*dzU
{indent}    trial_res=self._constraints(xt,ut,st)
{indent}    phit=self._barrier_phi(xt,ut,st,mu)
{indent}    tht=self._theta(*trial_res,'l1')
{indent}    ok,ftype=filt.trial(
{indent}        tht,phit,th_ref,phi_ref,alpha,dphi_ref)
{indent}    if ok:
{indent}        x,u,s=xt,ut,st
{indent}        lam,beta,gamma=lamt,betat,gammat
{indent}        zL,zU=zLt,zUt
{indent}        # Dormant direct-bound duals are inactive under v16.  If a
{indent}        # structural expanded ABI is present, keep its checkpoint value.
{indent}        accepted_trial=True;lsn=retry_lsn
{indent}        break
{indent}    alpha*=opt.gamma_alpha
{indent}
{indent}if opt.print_level:
{indent}    print(
{indent}        f"V29_WATCHDOG_ROLLBACK_RETRY it={{it}} "
{indent}        f"accepted={{accepted_trial}} alpha={{alpha:.9e}} "
{indent}        f"ls={{lsn}}",flush=True)
{indent}
{indent}watchdog_checkpoint=None
{indent}if not accepted_trial:
{indent}    status='line_search_failure'
{indent}    break
"""

    txt = txt[:m.start()] + retry + txt[m.end():]

    path.write_text(txt)
    py_compile.compile(str(path), doraise=True)
    print(f"Installed v29 watchdog retry patch: {path}")
    print(f"Backup: {backup}")
    return True


def restore(path: Path):
    backup = path.with_name(path.name + ".pre_v29_watchdog.bak")
    if not backup.exists():
        raise RuntimeError(f"No v29 backup exists: {backup}")
    shutil.copy2(backup, path)
    py_compile.compile(str(path), doraise=True)
    print(f"Restored pre-v29 solver: {path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--restore", action="store_true")
    ap.add_argument(
        "--solver-path",
        default="",
        help="Optional explicit solver.py path; normally auto-detected.",
    )
    a = ap.parse_args()

    path = Path(a.solver_path).resolve() if a.solver_path else solver_path()
    if a.restore:
        restore(path)
    else:
        apply_patch(path)


if __name__ == "__main__":
    main()
