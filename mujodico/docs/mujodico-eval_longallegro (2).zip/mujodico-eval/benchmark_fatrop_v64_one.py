#!/usr/bin/env python3
"""Run one FATROP contact benchmark configuration.

Important: platform and precision are configured before importing JAX.  Use the
suite driver for the full matrix of subprocess-isolated configurations.
"""
from __future__ import annotations
import argparse, json, os, platform as py_platform, sys, time
from pathlib import Path


def _preparse():
    p=argparse.ArgumentParser(add_help=False)
    p.add_argument('--platform',choices=['cpu','gpu'],default='cpu')
    p.add_argument('--dtype',choices=['float64','float32'],default='float64')
    p.add_argument('--jax-cache',default=os.path.expanduser('~/.cache/fatrop_pas_jax'))
    return p.parse_known_args()[0]

_pre=_preparse()
os.environ['JAX_PLATFORMS']='cpu' if _pre.platform=='cpu' else 'cuda'
os.environ['JAX_ENABLE_X64']='True' if _pre.dtype=='float64' else 'False'
os.environ.setdefault('JAX_COMPILATION_CACHE_DIR',_pre.jax_cache)
os.makedirs(_pre.jax_cache,exist_ok=True)

import numpy as np
import jax
import jax.numpy as jnp
jax.config.update('jax_enable_x64',_pre.dtype=='float64')
try:
    jax.config.update('jax_compilation_cache_dir',_pre.jax_cache)
    jax.config.update('jax_persistent_cache_min_compile_time_secs',0)
    jax.config.update('jax_persistent_cache_min_entry_size_bytes',-1)
except Exception:
    pass

from mujodico.examples.tasks import parse_task_name
from benchmark_fatrop_reference_contact import ContactProblem
from mujodico.trajopt._src.fatrop_ref import FatropRefOptions


def lifted_objective(task,x,u_aug):
    u=u_aug[:,:task.nu]
    e=x[:-1]-np.asarray(task.x_goal); du=u-np.asarray(task.u_ref)
    stage=np.einsum('ni,ij,nj->n',e,np.asarray(task.Q),e)+np.einsum('ni,ij,nj->n',du,np.asarray(task.R),du)
    ef=x[-1]-np.asarray(task.x_goal)
    return float(stage.sum()+ef@np.asarray(task.Qf)@ef)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--task',required=True)
    ap.add_argument('--solver',choices=['official','jax-serial','jax-pas'],required=True)
    ap.add_argument('--platform',choices=['cpu','gpu'],default='cpu')
    ap.add_argument('--dtype',choices=['float64','float32'],default='float64')
    ap.add_argument('--max-iters',type=int,default=150)
    ap.add_argument('--tol',type=float,default=None)
    ap.add_argument('--mu-min',type=float,default=None)
    ap.add_argument('--warmup-runs',type=int,default=1)
    ap.add_argument('--repeats',type=int,default=3)
    ap.add_argument('--print-level',type=int,default=0)
    ap.add_argument('--stagewise',choices=['auto','true','false'],default='auto')
    ap.add_argument('--jax-cache',default=os.path.expanduser('~/.cache/fatrop_pas_jax'))
    ap.add_argument('--fatrop-lib',default=os.environ.get('FATROP_LIB',''))
    ap.add_argument('--blasfeo-lib',default=os.environ.get('BLASFEO_LIB',''))
    ap.add_argument('--save-npz',default='')
    ap.add_argument('--official-cache',default='',
                    help='load/save the official FATROP solution at this path')
    ap.add_argument('--refresh-official-cache',action='store_true')
    ap.add_argument('--skip-rollout',action='store_true')
    ap.add_argument('--gpu-line-search',action='store_true',
                    help='use experimental device-side ordinary filter line search')
    ap.add_argument('--enable-watchdog',action='store_true',
                    help='enable the experimental watchdog globalization path')
    ap.add_argument('--jax-hessian',choices=['zero','cost','exact_lagrangian'],default='cost')
    ap.add_argument('--max-soc',type=int,default=4)
    ap.add_argument('--official-hessian',choices=['gauss-newton','exact'],
                    default='gauss-newton',
                    help='Hessian mode passed to CasADi FATROP')
    a=ap.parse_args()

    if a.solver=='official' and (a.platform!='cpu' or a.dtype!='float64'):
        raise SystemExit('official FATROP low-level/BLASFEO backend is CPU float64 only')
    dtype=jnp.float64 if a.dtype=='float64' else jnp.float32
    devices=[str(d) for d in jax.devices()]
    if a.platform=='gpu' and not any(('gpu' in d.lower() or 'cuda' in d.lower()) for d in devices):
        raise SystemExit(f'GPU requested but JAX devices are {devices}')

    task=parse_task_name(a.task)(0)
    tbuild=time.perf_counter(); problem=ContactProblem(task,dtype=dtype); build_seconds=time.perf_counter()-tbuild
    x0,u0=problem.init()
    tol=a.tol if a.tol is not None else (1e-8 if a.dtype=='float64' else 1e-6)
    mu_min=a.mu_min if a.mu_min is not None else (1e-11 if a.dtype=='float64' else 1e-7)
    stagewise=(a.platform=='cpu') if a.stagewise=='auto' else a.stagewise=='true'

    runs=[]; final=None
    if a.solver=='official':
        # Use the supported CasADi FATROP plugin as the behavioral oracle.  The
        # old low-level ctypes bridge can fail during structure detection and
        # still return a numeric iterate, which made failed solves look like a
        # valid (but wildly different) reference solution.
        import casadi as ca
        from mujodico.examples.methods.casadi_lifted_multiple_shooting import (
            CasadiFatropLiftedMultipleShooting,
        )
        from mujodico.examples.methods import support
        from mujodico import mjx
        cache_path=Path(a.official_cache) if a.official_cache else None
        cache_signature={'task':a.task,'max_iters':a.max_iters,
                         'tol':tol,'dtype':a.dtype,
                         'official_hessian':a.official_hessian}
        cache_hit=False
        if cache_path and cache_path.exists() and not a.refresh_official_cache:
            cached=np.load(cache_path,allow_pickle=False)
            cached_meta=json.loads(str(cached['metadata']))
            cache_hit=(cached_meta.get('_cache_signature')==cache_signature)
        if cache_hit:
            cached_stats=cached_meta.get('official_stats',{})
            cached_obj=float(cached_meta.get('solver_objective',
                                             lifted_objective(task,cached['x'],cached['u'])))
            def run():
                return (np.asarray(cached['x']),np.asarray(cached['u']),
                        cached_stats,cached_obj),0.0
        else:
            method=CasadiFatropLiftedMultipleShooting(
                task,mjx.ContactApproxType.HUNT_CROSSLEY,
                support.HessianApproxType.GaussNewton)
            equality=([1]*(task.nx+method.ncf)+[0]*method.nsoc)*task.horizon
            solver_options={
                    'fatrop.max_iter':a.max_iters,
                    'fatrop.tol':tol,
                    'fatrop.print_level':a.print_level,
                    'fatrop.hessian_approximation':a.official_hessian,
                    'structure_detection':'auto','equality':equality,
                    'print_time':False,'error_on_fail':False,
                }
            try:
                solver=ca.nlpsol(
                    f'official_fatrop_{a.task}_{os.getpid()}','fatrop',
                    method._nlp,solver_options)
                official_hessian_effective=a.official_hessian
            except RuntimeError as exc:
                # The current CasADi FATROP plugin advertises no
                # hessian_approximation option, although other CasADi solver
                # interfaces do.  Retain a working oracle and report the
                # effective mode instead of silently changing the comparison.
                if a.official_hessian == 'exact' and 'hessian' not in str(exc).lower():
                    raise
                solver_options.pop('fatrop.hessian_approximation',None)
                solver=ca.nlpsol(
                    f'official_fatrop_{a.task}_{os.getpid()}','fatrop',
                    method._nlp,solver_options)
                official_hessian_effective='plugin-default'
            z0=method._pack(task.xs_init,task.us_init,
                            np.zeros((task.horizon,method.ncf)))
            def run():
                t=time.perf_counter()
                sol=solver(x0=z0,lbx=method._vars_lb,ubx=method._vars_ub,
                           lbg=method._g_lb,ubg=method._g_ub)
                dt=time.perf_counter()-t
                x,physical_u,contact_force=method._unpack(
                    np.asarray(sol['x']).reshape(-1))
                return (x,np.concatenate([physical_u,contact_force],axis=1),
                        dict(solver.stats()),float(sol['f'])),dt
    else:
        backend='serial' if a.solver=='jax-serial' else 'pas'
        opts=FatropRefOptions(max_iter=a.max_iters,linear_backend=backend,hessian_mode=a.jax_hessian,print_level=a.print_level,
                              max_soc=a.max_soc, enable_watchdog=a.enable_watchdog,
                              tol=tol,mu_min=mu_min,acceptable_tol=(1e-6 if a.dtype=='float64' else 1e-5))
        if a.gpu_line_search:
            # The experimental device path currently covers ordinary
            # backtracking.  Disable SOC so the comparison exercises exactly
            # the same globalization policy in both benchmark runs.
            opts=FatropRefOptions(**{**opts.__dict__,
                                     'use_gpu_line_search':True,
                                     'max_soc':0})
        def run():
            t=time.perf_counter(); r=problem.ref.solve(x0,u0,opts,stagewise=stagewise)
            # Ensure all device work is complete before stopping the clock.
            jax.block_until_ready(jnp.asarray(r.u)); return r,time.perf_counter()-t

    warm=[]
    for _ in range(a.warmup_runs):
        r,dt=run(); warm.append(dt)
    for i in range(a.repeats):
        r,dt=run(); final=r; runs.append(dt)

    if a.solver=='official':
        x,u,stats,solver_objective=final
        status=str(stats.get('return_status','unknown'))
        iterations=int(stats.get('iter_count',-1))
        internal=float(stats.get('t_wall_total',float('nan')))
        extra={'official_stats':stats,'solver_objective':solver_objective,
               'reference':'casadi-fatrop'}
    else:
        x=np.asarray(final.x);u=np.asarray(final.u);status=final.status;iterations=int(final.iterations);internal=float(final.solve_time)
        extra={'mu':float(final.mu),'accepted_steps':int(final.accepted_steps)}

    obj=lifted_objective(task,x,u)
    if a.skip_rollout:
        goal=float('nan')
    else:
        goal,_,_=problem.exact_rollout(u[:,:task.nu]); goal=float(goal)
    result={
        'task':a.task,'solver':a.solver,'platform':a.platform,'dtype':a.dtype,
        'hessian':(official_hessian_effective if a.solver=='official'
                   else a.jax_hessian),
        'N':int(task.horizon),'nx':int(task.nx),'nu_physical':int(task.nu),
        'ncf':int(problem.ncf),'nu_aug':int(task.nu+problem.ncf),'ne':int(problem.ref.ne),'ni':int(problem.ref.ni),
        'status':status,'iterations':iterations,'objective':obj,'physical_goal':goal,
        'build_seconds':build_seconds,'warmup_seconds':warm,'timed_seconds':runs,
        'median_seconds':float(np.median(runs)) if runs else float('nan'),
        'min_seconds':float(np.min(runs)) if runs else float('nan'),
        'mean_seconds':float(np.mean(runs)) if runs else float('nan'),
        'internal_last_seconds':internal,'stagewise':stagewise,'jax_devices':devices,
        'python':sys.version.split()[0],'jax_version':jax.__version__,'host':py_platform.node(),
        **extra,
    }
    if a.save_npz:
        Path(a.save_npz).parent.mkdir(parents=True,exist_ok=True)
        np.savez(a.save_npz,x=x,u=u,metadata=json.dumps(result))
    if a.solver=='official' and a.official_cache and (
            a.refresh_official_cache or not Path(a.official_cache).exists()):
        cp=Path(a.official_cache);cp.parent.mkdir(parents=True,exist_ok=True)
        cache_meta=dict(result);cache_meta['_cache_signature']=cache_signature
        np.savez(cp,x=x,u=u,metadata=json.dumps(cache_meta))
    print('BENCHMARK_RESULT '+json.dumps(result,sort_keys=True),flush=True)

if __name__=='__main__': main()
