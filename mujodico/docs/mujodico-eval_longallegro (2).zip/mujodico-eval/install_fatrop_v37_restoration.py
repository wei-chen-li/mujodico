#!/usr/bin/env python3
from __future__ import annotations
import argparse, shutil
from pathlib import Path

def solver_path():
    import mujodico.trajopt._src.fatrop_ref.solver as sm
    return Path(sm.__file__).resolve()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--solver-path",default="")
    a=ap.parse_args()
    sp=Path(a.solver_path).resolve() if a.solver_path else solver_path()
    target=sp.with_name("restoration_v32.py")
    backup=sp.with_name("restoration_v32.py.pre_v37_pair_condensation.bak")
    if target.exists() and not backup.exists():
        shutil.copy2(target,backup)
    shutil.copy2(Path(__file__).with_name("restoration_v37.py"),target)
    print("Installed v37 paired-elastic condensation:",target)
    print("Backup:",backup)

if __name__=="__main__":
    main()
