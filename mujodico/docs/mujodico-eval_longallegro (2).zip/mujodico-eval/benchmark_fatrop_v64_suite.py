#!/usr/bin/env python3
"""Subprocess-isolated FATROP contact benchmark suite."""
from __future__ import annotations
import argparse,csv,json,os,subprocess,sys,time
from pathlib import Path

TASKS=['PushSphere2d','PushBox2d','PushCircularKnob','PushSquareKnob','FingersSphere2d']
CONFIGS={
 'official-cpu-f64':('official','cpu','float64'),
 'serial-cpu-f64':('jax-serial','cpu','float64'),
 'pas-cpu-f64':('jax-pas','cpu','float64'),
 'serial-gpu-f64':('jax-serial','gpu','float64'),
 'pas-gpu-f64':('jax-pas','gpu','float64'),
 'serial-gpu-f32':('jax-serial','gpu','float32'),
 'pas-gpu-f32':('jax-pas','gpu','float32'),
}

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--tasks',nargs='+',default=TASKS)
 ap.add_argument('--configs',nargs='+',default=list(CONFIGS))
 ap.add_argument('--max-iters',type=int,default=150);ap.add_argument('--repeats',type=int,default=3);ap.add_argument('--warmup-runs',type=int,default=1)
 ap.add_argument('--print-level',type=int,default=0);ap.add_argument('--outdir',default='fatrop_contact_results')
 ap.add_argument('--jax-cache',default=os.path.expanduser('~/.cache/fatrop_pas_jax'))
 ap.add_argument('--fatrop-lib',default=os.environ.get('FATROP_LIB',''));ap.add_argument('--blasfeo-lib',default=os.environ.get('BLASFEO_LIB',''))
 ap.add_argument('--skip-rollout',action='store_true');ap.add_argument('--fail-fast',action='store_true')
 ap.add_argument('--per-run-timeout',type=float,default=0.0,help='seconds; 0 disables subprocess timeout')
 a=ap.parse_args();out=Path(a.outdir);out.mkdir(parents=True,exist_ok=True)
 bad=[t for t in a.tasks if t not in TASKS];
 if bad: raise SystemExit(f'Unknown tasks {bad}; choices={TASKS}')
 bad=[c for c in a.configs if c not in CONFIGS];
 if bad: raise SystemExit(f'Unknown configs {bad}; choices={list(CONFIGS)}')
 rows=[]
 for task in a.tasks:
  for cfg in a.configs:
   solver,platform,dtype=CONFIGS[cfg]
   log=out/f'{task}__{cfg}.log';npz=out/f'{task}__{cfg}.npz'
   cmd=[sys.executable,str(Path(__file__).with_name('benchmark_fatrop_v64_one.py')),'--task',task,'--solver',solver,'--platform',platform,'--dtype',dtype,
        '--max-iters',str(a.max_iters),'--repeats',str(a.repeats),'--warmup-runs',str(a.warmup_runs),'--print-level',str(a.print_level),'--jax-cache',a.jax_cache,'--save-npz',str(npz)]
   if solver=='official':
    cmd += ['--official-cache',str(out/'official_cache'/f'{task}.npz')]
   if a.fatrop_lib: cmd += ['--fatrop-lib',a.fatrop_lib]
   if a.blasfeo_lib: cmd += ['--blasfeo-lib',a.blasfeo_lib]
   if a.skip_rollout: cmd += ['--skip-rollout']
   print(f'=== {task} / {cfg} ===',flush=True); t=time.time()
   try:
    p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=(a.per_run_timeout or None))
    stdout=p.stdout; returncode=p.returncode
   except subprocess.TimeoutExpired as e:
    stdout=(e.stdout or '') + f'\nTIMEOUT after {a.per_run_timeout} s\n'; returncode=124
   log.write_text(stdout); print(stdout,end='')
   marker=[ln for ln in stdout.splitlines() if ln.startswith('BENCHMARK_RESULT ')]
   if marker:
    row=json.loads(marker[-1].split(' ',1)[1]);row['config']=cfg;row['returncode']=returncode;rows.append(row)
   else:
    rows.append({'task':task,'config':cfg,'solver':solver,'platform':platform,'dtype':dtype,'status':'ERROR_OR_SKIPPED','returncode':returncode,'log':str(log)})
   # Incremental persistence makes long GPU/contact sweeps crash-safe.
   (out/'results.json').write_text(json.dumps(rows,indent=2,sort_keys=True))
   keys=sorted({k for r in rows for k in r if not isinstance(r.get(k),(list,dict))})
   with (out/'results.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
   if returncode and a.fail_fast: raise SystemExit(returncode)
 print(f'Wrote {out/"results.csv"} and {out/"results.json"}')
if __name__=='__main__':main()
