"""Plot Allegro ball goal error from a trajectory saved by the examples runner.

Example:
  python plot_allegro_ball_goal_error.py /tmp/allegro_ball.npz \
      --output /tmp/allegro_ball_goal_error.pdf
"""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
plt.rcParams.update({
    "text.usetex": True,
    "font.family": "serif",
    "font.serif": ["Computer Modern"]
})

def _orientation_error_degrees(quaternions, goal_quaternion):
  # q and -q represent the same rotation, so use the absolute dot product.
  dot = np.abs(quaternions @ goal_quaternion)
  print(dot)
  dot = np.clip(dot, -1.0, 1.0)
  return np.rad2deg(2.0 * np.arccos(dot))


def main():
  parser = argparse.ArgumentParser()
  parser.add_argument('trajectory', type=Path)
  parser.add_argument('--output', type=Path, default=None)
  args = parser.parse_args()

  data = np.load(args.trajectory)
  xs = data['xs']
  x_goal = data['x_goal']
  timestep = float(data['timestep'])
  time = np.arange(xs.shape[0]) * timestep

  position_error = xs[:, 16:19] - x_goal[16:19]
  orientation_error = _orientation_error_degrees(
      xs[:, 19:23], x_goal[19:23]
  )
  # print(position_error)
  # print(orientation_error)
  print(xs[:, 19:23])
  print(x_goal[19:23])

  plt.rcParams.update({
      'font.family': 'serif',
      'mathtext.fontset': 'cm',
      'axes.labelsize': 11,
      'axes.titlesize': 11,
      'xtick.labelsize': 9,
      'ytick.labelsize': 9,
   })
  fig, axes = plt.subplots(
      4, 1, figsize=(5.2, 6.2), sharex=True, constrained_layout=True
  )
  labels = [r'$e_x$ (m)', r'$e_y$ (m)', r'$e_z$ (m)',
            r'$e_R$ (deg)']
  values = [position_error[:, 0], position_error[:, 1],
            position_error[:, 2], orientation_error]
  colors = ['#4267ac', '#4c956c', '#bc4749', '#7b2cbf']

  for ax, value, label, color in zip(axes, values, labels, colors):
    ax.plot(time, value, color=color, linewidth=1.8)
    ax.axhline(0.0, color='0.35', linewidth=0.8, linestyle=(0, (4, 3)))
    ax.set_ylabel(label)
    ax.grid(axis='y', color='0.88', linewidth=0.7)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.margins(x=0.01)

  axes[-1].set_xlabel('time (s)')
  task_name = str(data['task']) if 'task' in data else 'Allegro ball'
  fig.suptitle(task_name, fontsize=13)

  if args.output is None:
    plt.show()
  else:
    args.output.parent.mkdir(parents=True, exist_ok=True)
    output = args.output.with_suffix('.pdf')
    fig.savefig(output, format='pdf', bbox_inches='tight')
    print(output)


if __name__ == '__main__':
  main()
