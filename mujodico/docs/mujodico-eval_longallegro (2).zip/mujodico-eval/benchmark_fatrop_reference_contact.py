# JAX platform, precision, and cache policy are configured by the caller.
"""Shared lifted-contact problem used by JAX and official FATROP benchmarks."""
from dataclasses import dataclass

import jax
import jax.numpy as jnp
import numpy as np

from mujodico import mjx
from mujodico.trajopt._src.fatrop_ref import FatropReferenceJAX


def step_given_efc_force(model, x, u, efc_force):
    data = mjx.make_data(model, impl=model.impl)
    data = data.replace(
        qpos=x[:model.nq], qvel=x[model.nq:model.nq + model.nv],
        act=x[model.nq + model.nv:], ctrl=u)
    data = mjx.fwd_position(model, data)
    data = mjx.fwd_velocity(model, data)
    data = mjx.fwd_actuation(model, data)
    data = mjx.fwd_acceleration(model, data)
    data = data.tree_replace({
        'qfrc_constraint': data._impl.efc_J.T @ efc_force,
        '_impl.efc_force': efc_force, 'qacc': None})
    if model.opt.integrator == mjx.IntegratorType.EULER:
        data = mjx.euler(model, data)
    elif model.opt.integrator == mjx.IntegratorType.IMPLICITFAST:
        data = mjx.implicit(model, data)
    else:
        raise NotImplementedError(model.opt.integrator)
    return jnp.concatenate((data.qpos, data.qvel, data.act))


@dataclass(frozen=True)
class SOC:
    start_index: int
    dim: int
    friction: jax.Array


class ContactProblem:
    """The exact lifted formulation used by CasADiFatropLiftedMultipleShooting.

    CasADi's variable bounds are represented by identity path rows here because
    FATROP's IPM internally introduces slacks and bound multipliers for them.
    """
    def __init__(self, task, contact_approx=mjx.ContactApproxType.HUNT_CROSSLEY,
                 dtype=jnp.float64):
        self.task, self.nu, self.dtype = task, task.nu, dtype
        model = mjx.put_model(
            task.model, impl='jax', contact_approximation=contact_approx,
            contact_smoothing=task.contact_smoothing * 0.01)
        if dtype == jnp.float32:
            def cast_leaf(value):
                if hasattr(value, 'dtype') and jnp.issubdtype(value.dtype, jnp.inexact):
                    return value.astype(jnp.float32)
                return value
            model = jax.tree.map(cast_leaf, model)
        data = mjx.make_data(model, impl=model.impl)
        self.mm, self.md = model, data

        types = np.asarray(data._impl.efc_type)
        addresses = np.nonzero(
            (types == mjx.ConstraintType.CONTACT_FRICTIONLESS) |
            (types == mjx.ConstraintType.CONTACT_PYRAMIDAL) |
            (types == mjx.ConstraintType.CONTACT_ELLIPTIC))[0]
        self.addrs, self.ncf = addresses, int(addresses.size)
        dims = np.asarray(data._impl.contact.dim)
        efc_addresses = np.asarray(data._impl.contact.efc_address)
        elliptic = types[efc_addresses] == mjx.ConstraintType.CONTACT_ELLIPTIC
        positioned = mjx.fwd_position(model, data) if np.any(elliptic) else data
        socs = []
        for i in np.nonzero(elliptic)[0]:
            hit = np.nonzero(efc_addresses[i] == addresses)[0]
            if len(hit):
                dim = int(dims[i])
                socs.append(SOC(int(hit[0]), dim,
                                positioned._impl.contact.friction[i, :dim - 1]))
        self.socs = socs

        x_goal = jnp.asarray(task.x_goal, dtype=dtype)
        Q, Qf = jnp.asarray(task.Q, dtype=dtype), jnp.asarray(task.Qf, dtype=dtype)
        u_ref, R = jnp.asarray(task.u_ref, dtype=dtype), jnp.asarray(task.R, dtype=dtype)

        def forward(x, u):
            d = data.replace(qpos=x[:model.nq],
                             qvel=x[model.nq:model.nq + model.nv],
                             act=x[model.nq + model.nv:], ctrl=u)
            return mjx.forward(model, d)._impl.efc_force[addresses]

        def advance(x, u, contact_force):
            force = jnp.zeros(data._impl.nefc, dtype=x.dtype).at[addresses].set(contact_force)
            return step_given_efc_force(model, x, u, force)

        self.forward, self.advance = jax.jit(forward), jax.jit(advance)
        self.physical_step = jax.jit(lambda x, u: (advance(x, u, forward(x, u)), forward(x, u)))

        def stage_cost(x, augmented_u):
            dx, du = x - x_goal, augmented_u[:task.nu] - u_ref
            return dx @ (Q @ dx) + du @ (R @ du)

        def terminal_cost(x):
            dx = x - x_goal
            return dx @ (Qf @ dx)

        def transition(x, augmented_u):
            return advance(x, augmented_u[:task.nu], augmented_u[task.nu:])

        def stage_equality(x, augmented_u):
            return augmented_u[task.nu:] - forward(x, augmented_u[:task.nu])

        self.stage_cost, self.terminal_cost = stage_cost, terminal_cost
        self.transition, self.stage_eq = transition, stage_equality

        control_lb, control_ub = task.u_bounds
        np_dtype = np.float32 if dtype == jnp.float32 else np.float64
        state_lb, state_ub = task.x_bounds
        state_bounded = np.nonzero(
            np.isfinite(state_lb) | np.isfinite(state_ub))[0].astype(np.int32)
        force_lb = np.zeros(self.ncf, dtype=np_dtype)
        force_ub = np.full(self.ncf, np.inf, dtype=np_dtype)
        for soc in socs:
            force_lb[soc.start_index + 1:soc.start_index + soc.dim] = -np.inf
        augmented_lb = np.concatenate([control_lb, force_lb])
        augmented_ub = np.concatenate([control_ub, force_ub])
        bounded = np.nonzero(np.isfinite(augmented_lb) | np.isfinite(augmented_ub))[0].astype(np.int32)
        self.bounded = bounded
        # CasADi FATROP receives x/u bounds as variable bounds.  The JAX
        # reference represents those same bounds as identity path rows so the
        # structured solver can handle them through its existing slack/bound
        # machinery.  State rows must precede control rows only by convention;
        # their ordering is otherwise immaterial.
        inequality_lb = [state_lb[i] for i in state_bounded]
        inequality_ub = [state_ub[i] for i in state_bounded]
        inequality_lb += [augmented_lb[i] for i in bounded]
        inequality_ub += [augmented_ub[i] for i in bounded]
        for _ in socs:
            inequality_lb.append(-np.inf)
            inequality_ub.append(0.0)
        inequality_lb = np.asarray(inequality_lb, dtype=np_dtype)
        inequality_ub = np.asarray(inequality_ub, dtype=np_dtype)
        bounded_jax = jnp.asarray(bounded)

        state_bounded_jax = jnp.asarray(state_bounded)

        def stage_inequality(x, augmented_u):
            values = []
            if state_bounded.size:
                values.append(x[state_bounded_jax])
            if bounded.size:
                values.append(augmented_u[bounded_jax])
            contact_force = augmented_u[task.nu:]
            for soc in socs:
                normal = contact_force[soc.start_index]
                tangent = (contact_force[soc.start_index + 1:soc.start_index + soc.dim]
                           / soc.friction)
                values.append(jnp.asarray([tangent @ tangent - normal * normal]))
            return jnp.concatenate(values) if values else jnp.zeros((0,), dtype=augmented_u.dtype)

        self.stage_ineq = stage_inequality
        self.ineq_lb, self.ineq_ub = inequality_lb, inequality_ub
        self.ref = FatropReferenceJAX(
            horizon=task.horizon, num_states=task.nx,
            num_controls=task.nu + self.ncf,
            x0=jnp.asarray(task.x_0, dtype=dtype), stage_cost=stage_cost,
            terminal_cost=terminal_cost, transition=transition,
            stage_equality=stage_equality, stage_inequality=stage_inequality,
            ineq_lb=inequality_lb, ineq_ub=inequality_ub)

    def init(self):
        np_dtype = np.float32 if self.dtype == jnp.float32 else np.float64
        x = np.asarray(self.task.xs_init, dtype=np_dtype)
        u = np.asarray(self.task.us_init, dtype=np_dtype)
        contact_force = np.zeros((self.task.horizon, self.ncf), dtype=np_dtype)
        return x, np.concatenate([u, contact_force], axis=1)

    def exact_rollout(self, controls):
        x = jnp.asarray(self.task.x_0, dtype=self.dtype)
        states, forces = [x], []
        for k in range(self.task.horizon):
            x, force = self.physical_step(x, jnp.asarray(controls[k], dtype=self.dtype))
            states.append(x)
            forces.append(force)
        states, forces = jnp.stack(states), jnp.stack(forces)
        error = states[-1] - jnp.asarray(self.task.x_goal, dtype=self.dtype)
        goal = float(error @ (jnp.asarray(self.task.Q, dtype=self.dtype) @ error))
        return goal, np.asarray(states), np.asarray(forces)
