#!/usr/bin/env python3
"""Integrate the validated v43 restoration into the v29 FATROP outer state machine.

This is a source-local patcher:
- requires V29_EXACT_WATCHDOG_RETRY already installed;
- preserves the installed solver ABI, including expanded dormant zuL/zuU state;
- replaces ONLY the v29 watchdog rollback/ordinary-retry branch;
- invokes restoration_v32.full_restoration at the saved watchdog checkpoint;
- v43 hard-dynamics restoration is installed at runtime in the worker process;
- resets the original filter and arms a fresh watchdog at the restored point.

It intentionally does NOT replace solver.py wholesale.
"""
from __future__ import annotations

import argparse
import py_compile
import re
import shutil
from pathlib import Path

MARKER = "# V44_INTEGRATED_NATIVE_RESTORATION"


def solver_path():
    import mujodico.trajopt._src.fatrop_ref.solver as sm
    return Path(sm.__file__).resolve()


def apply_patch(path: Path):
    txt = path.read_text()

    if MARKER in txt:
        print(f"V44 patch already installed: {path}")
        return False

    required = [
        "# V29_EXACT_WATCHDOG_RETRY",
        "watchdog_rejected_trial=True",
        "watchdog_checkpoint['saved_sol']=sol",
        "V29_WATCHDOG_ROLLBACK_RETRY",
    ]
    missing = [q for q in required if q not in txt]
    if missing:
        raise RuntimeError(
            "V44 expects the installed v29 watchdog branch. "
            f"Missing markers: {missing}\nSolver: {path}"
        )

    backup = path.with_name(path.name + ".pre_v44_restoration.bak")
    if not backup.exists():
        shutil.copy2(path, backup)

    # Match the exact v29 rollback/retry body, leaving surrounding watchdog
    # bookkeeping untouched.
    pat = re.compile(
        r"""(?P<i>[ ]{24})wb=watchdog_checkpoint\n"""
        r"""(?P=i)\# V29_EXACT_WATCHDOG_RETRY\n"""
        r"""(?:(?P=i).*\n)+?"""
        r"""(?P=i)watchdog_checkpoint=None\n"""
        r"""(?P=i)if not accepted_trial:\n"""
        r"""(?P=i)    status='line_search_failure'\n"""
        r"""(?P=i)    break\n"""
    )
    m = pat.search(txt)
    if m is None:
        raise RuntimeError(
            "Could not locate the v29 rollback/retry block. "
            "Send the current solver.py if this branch has changed."
        )

    i = m.group("i")

    repl = f"""\
{i}wb=watchdog_checkpoint
{i}{MARKER}
{i}# The watchdog excursion failed.  Native FATROP restores the saved
{i}# pre-watchdog point and enters restoration rather than committing the
{i}# v29 ordinary rollback/backtracking branch.
{i}x,u,s=wb['x'],wb['u'],wb['s']
{i}lam,beta,gamma=wb['lam'],wb['beta'],wb['gamma']
{i}zL,zU=wb['zL'],wb['zU']
{i}mu=float(wb['mu'])
{i}last_reg=float(wb['last_reg'])
{i}last_nonzero_reg=float(wb['last_nonzero_reg'])
{i}filt.entries=list(wb['filter_entries'])
{i}
{i}# Preserve optional dormant direct-bound state carried by expanded ABIs.
{i}if 'zuL' in locals() and 'saved_zuL' in wb:
{i}    zuL=wb['saved_zuL']
{i}if 'zuU' in locals() and 'saved_zuU' in wb:
{i}    zuU=wb['saved_zuU']
{i}
{i}# Install the v43 hard-dynamics correction in THIS worker process.  The
{i}# benchmark harness launches subprocesses, so parent-only monkey patches
{i}# would not be sufficient.
{i}from . import restoration_v32 as _v44_rv
{i}if not getattr(_v44_rv,'_v44_hard_dynamics_installed',False):
{i}    from fatrop_v43_runtime_patch import install_v43_hard_dynamics
{i}    install_v43_hard_dynamics(_v44_rv)
{i}    _v44_rv._v44_hard_dynamics_installed=True
{i}
{i}if opt.print_level:
{i}    print(
{i}        f"V44_RESTORATION_ENTER it={{it}} "
{i}        f"J={{self._objective(x,u):.9e}} "
{i}        f"cv={{self._theta(*self._constraints(x,u,s),'linf'):.9e}}",
{i}        flush=True)
{i}
{i}_rr=_v44_rv.full_restoration(
{i}    self,
{i}    x=x,u=u,s=s,
{i}    lam=lam,beta=beta,gamma=gamma,
{i}    zL=zL,zU=zU,
{i}    mu_orig=mu,
{i}    opt=opt,
{i}    stagewise=stagewise,
{i}    outer_iteration=max(0,it-1),
{i}    backend=opt.linear_backend,
{i}    print_rows=bool(opt.print_level),
{i})
{i}
{i}if not bool(_rr.success):
{i}    watchdog_active=False;watchdog_steps=0
{i}    watchdog_checkpoint=None;shortened_count=0
{i}    status='restoration_failure'
{i}    if opt.print_level:
{i}        print(
{i}            f"V44_RESTORATION_FAILED it={{it}} "
{i}            f"reason={{_rr.reason}}",flush=True)
{i}    break
{i}
{i}# Handoff the validated restoration primal/dual point back to the original
{i}# NLP.  The restoration module already applies the native multiplier/bound
{i}# reset/refit policy.
{i}x=_rr.x;u=_rr.u;s=_rr.s
{i}lam=_rr.lambda_dyn;beta=_rr.beta_eq;gamma=_rr.gamma_ineq
{i}zL=_rr.zL;zU=_rr.zU
{i}mu=float(wb['mu'])  # original barrier parameter is unchanged
{i}
{i}# Restoration starts a fresh original-NLP globalization neighborhood.
{i}lin=self._linearize(x,u,stagewise)
{i}_th_rest=self._theta(*self._constraints(x,u,s),'l1')
{i}_phi_rest=self._barrier_phi(x,u,s,mu)
{i}filt=_Filter(_th_rest,opt)
{i}shortened_count=0
{i}acceptable_count=0
{i}last_reg=0.0
{i}last_nonzero_reg=0.0
{i}accepted+=int(_rr.iterations)
{i}
{i}# Native immediately probes the restored basin with watchdog semantics
{i}# (the saved official Fingers trace has a `w` row directly after 14r).
{i}watchdog_active=True
{i}watchdog_steps=0
{i}watchdog_rejected_trial=False
{i}watchdog_checkpoint=dict(
{i}    x=x,u=u,s=s,lam=lam,beta=beta,gamma=gamma,zL=zL,zU=zU,
{i}    mu=mu,last_reg=last_reg,last_nonzero_reg=last_nonzero_reg,
{i}    filter_entries=list(filt.entries),
{i}    theta=_th_rest,phi=_phi_rest,
{i}    dphi=None,alpha_test=None)
{i}if 'zuL' in locals():
{i}    watchdog_checkpoint['saved_zuL']=zuL
{i}if 'zuU' in locals():
{i}    watchdog_checkpoint['saved_zuU']=zuU
{i}
{i}# Add the restored original-NLP point to our trace.  The internal
{i}# restoration printer emits the r rows when print_level>0.
{i}_r_alpha=(float(_rr.rows[-1].get('alpha_pr',0.0))
{i}          if getattr(_rr,'rows',None) else 0.0)
{i}record(it,_r_alpha,0.0,max(1,int(_rr.iterations)),'r',0.0)
{i}
{i}if opt.print_level:
{i}    print(
{i}        f"V44_RESTORATION_HANDOFF it={{it}} "
{i}        f"J={{self._objective(x,u):.9e}} "
{i}        f"cv={{self._theta(*self._constraints(x,u,s),'linf'):.9e}} "
{i}        f"steps={{int(_rr.iterations)}}",flush=True)
{i}
{i}# The provisional watchdog point that triggered this branch is discarded.
{i}# Resume from the restored point on the next original-NLP Newton solve.
{i}continue
"""

    txt = txt[:m.start()] + repl + txt[m.end():]

    path.write_text(txt)
    py_compile.compile(str(path), doraise=True)
    print(f"Installed v44 integrated restoration patch: {path}")
    print(f"Backup: {backup}")
    return True


def restore(path: Path):
    backup = path.with_name(path.name + ".pre_v44_restoration.bak")
    if not backup.exists():
        raise RuntimeError(f"No v44 backup exists: {backup}")
    shutil.copy2(backup, path)
    py_compile.compile(str(path), doraise=True)
    print(f"Restored pre-v44 solver: {path}")


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--restore",action="store_true")
    ap.add_argument("--solver-path",default="")
    a=ap.parse_args()
    p=Path(a.solver_path).resolve() if a.solver_path else solver_path()
    if a.restore:
        restore(p)
    else:
        apply_patch(p)


if __name__=="__main__":
    main()
