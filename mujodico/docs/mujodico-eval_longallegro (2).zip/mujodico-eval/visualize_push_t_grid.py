"""Create an interactive HTML summary from a partial PushTShape2d grid CSV."""

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

import plotly.graph_objects as go
from plotly.subplots import make_subplots


PARAMS = (
    'mass_scale', 'damping', 'timestep', 'q_position', 'q_theta',
    'q_velocity_scale',
)


def read_rows(path: Path) -> list[dict]:
  rows = []
  with path.open(newline='') as input_file:
    for row in csv.DictReader(input_file):
      try:
        row['seed'] = int(row['seed'])
        row['goal_error'] = float(row['goal_error'])
        row['solve_time_sec'] = float(row['solve_time_sec'])
        for name in PARAMS:
          row[name] = float(row[name])
      except (TypeError, ValueError):
        # Ignore rows that are incomplete or contain a solver exception.
        continue
      if math.isfinite(row['goal_error']) and math.isfinite(row['solve_time_sec']):
        rows.append(row)
  return rows


def mean(values: list[float]) -> float:
  return sum(values) / len(values)


def make_figure(rows: list[dict], source: Path) -> go.Figure:
  by_config = defaultdict(list)
  by_seed = defaultdict(list)
  for row in rows:
    by_config[tuple(row[name] for name in PARAMS)].append(row)
    by_seed[row['seed']].append(row['goal_error'])

  configs = []
  for values, config_rows in by_config.items():
    item = dict(zip(PARAMS, values))
    item['mean_error'] = mean([r['goal_error'] for r in config_rows])
    item['best_error'] = min(r['goal_error'] for r in config_rows)
    item['mean_time'] = mean([r['solve_time_sec'] for r in config_rows])
    item['count'] = len(config_rows)
    configs.append(item)
  configs.sort(key=lambda item: item['mean_error'])

  fig = make_subplots(
      rows=2,
      cols=2,
      subplot_titles=(
          'Mass / damping / timestep',
          'Q position / Q rotation',
          'Mean error by seed',
          'Best configurations',
      ),
      specs=[[{}, {}], [{}, {'type': 'table'}]],
  )

  fig.add_trace(go.Scatter(
      x=[c['mass_scale'] for c in configs],
      y=[c['damping'] for c in configs],
      mode='markers',
      marker=dict(
          size=[7 + 2 * math.log10(max(c['mean_time'], 1e-3) + 1) for c in configs],
          color=[math.log10(max(c['mean_error'], 1e-12)) for c in configs],
          colorscale='Viridis',
          colorbar=dict(title='log10 mean error', x=0.46),
      ),
      text=[
          f"dt={c['timestep']:g}, qpos={c['q_position']:g}, "
          f"qθ={c['q_theta']:g}, qvel={c['q_velocity_scale']:g}, "
          f"error={c['mean_error']:.4g}, time={c['mean_time']:.3f}s"
          for c in configs
      ],
      hovertemplate='%{text}<extra></extra>',
      name='configuration',
  ), row=1, col=1)

  fig.add_trace(go.Scatter(
      x=[c['q_position'] for c in configs],
      y=[c['q_theta'] for c in configs],
      mode='markers',
      marker=dict(
          size=9,
          color=[math.log10(max(c['mean_error'], 1e-12)) for c in configs],
          colorscale='Plasma',
          showscale=False,
      ),
      text=[
          f"mass={c['mass_scale']:g}, damping={c['damping']:g}, "
          f"dt={c['timestep']:g}, qvel={c['q_velocity_scale']:g}, "
          f"error={c['mean_error']:.4g}"
          for c in configs
      ],
      hovertemplate='%{text}<extra></extra>',
      name='Q configuration',
  ), row=1, col=2)

  seed_values = sorted(by_seed)
  fig.add_trace(go.Bar(
      x=[str(seed) for seed in seed_values],
      y=[mean(by_seed[seed]) for seed in seed_values],
      name='seed mean',
  ), row=2, col=1)

  top = configs[: min(25, len(configs))]
  headers = ['mean error', 'best error', 'mass', 'damping', 'dt', 'qpos', 'qθ', 'qvel', 'n']
  columns = [
      [f"{c['mean_error']:.5g}" for c in top],
      [f"{c['best_error']:.5g}" for c in top],
      [f"{c['mass_scale']:g}" for c in top],
      [f"{c['damping']:g}" for c in top],
      [f"{c['timestep']:g}" for c in top],
      [f"{c['q_position']:g}" for c in top],
      [f"{c['q_theta']:g}" for c in top],
      [f"{c['q_velocity_scale']:g}" for c in top],
      [str(c['count']) for c in top],
  ]
  fig.add_trace(go.Table(
      header=dict(values=headers),
      cells=dict(values=columns),
  ), row=2, col=2)

  fig.update_xaxes(title_text='mass scale', row=1, col=1)
  fig.update_yaxes(title_text='slide damping', row=1, col=1)
  fig.update_xaxes(title_text='position Q', row=1, col=2)
  fig.update_yaxes(title_text='rotation Q', row=1, col=2)
  fig.update_xaxes(title_text='seed', row=2, col=1)
  fig.update_yaxes(title_text='mean weighted goal error', row=2, col=1)
  fig.update_layout(
      title=f'PushTShape2d grid results ({len(rows)} completed rows from {source.name})',
      height=900,
      width=1400,
      template='plotly_white',
  )
  return fig


def main() -> None:
  parser = argparse.ArgumentParser(description=__doc__)
  parser.add_argument('input', type=Path, help='Grid CSV, including a partial CSV.')
  parser.add_argument('--output', type=Path, default=Path('push_t_grid.html'))
  args = parser.parse_args()
  rows = read_rows(args.input)
  if not rows:
    parser.error(f'no completed rows found in {args.input}')
  args.output.parent.mkdir(parents=True, exist_ok=True)
  make_figure(rows, args.input).write_html(args.output, include_plotlyjs='cdn')
  print(f'wrote {args.output} using {len(rows)} completed rows')


if __name__ == '__main__':
  main()
