"""Compare cached official FATROP and JAX PAS trajectories in the task Viser UI.

Example:
  python visualize_fatrop_v64.py --task PushSphere2d \
      --official /tmp/fatrop-correctness/PushSphere2d__official-cpu-f64.npz \
      --jax /tmp/pas_pushsphere_f64_150.npz
"""

from __future__ import annotations

import argparse
import threading
import time
from pathlib import Path

import mjviser
import mujoco
import numpy as np
import viser

from mujodico.examples.tasks import get_task_names, parse_task_name


_DEFAULT_OFFICIAL = {
    "PushSphere2d": "/tmp/fatrop-correctness/PushSphere2d__official-cpu-f64.npz",
}
_DEFAULT_JAX = {
    "PushSphere2d": "/tmp/pas_pushsphere_f64_150.npz",
}


def _load_xs(path: Path) -> np.ndarray:
  with np.load(path, allow_pickle=False) as data:
    if "x" not in data:
      raise ValueError(f"{path} does not contain an 'x' trajectory")
    xs = np.asarray(data["x"], dtype=np.float64)
  if xs.ndim != 2:
    raise ValueError(f"{path}: expected x with shape (time, state), got {xs.shape}")
  return xs


def _label(path: Path, fallback: str) -> str:
  return fallback if path is None else path.stem


def main() -> None:
  parser = argparse.ArgumentParser(description=__doc__)
  parser.add_argument("--task", default="PushSphere2d", choices=get_task_names())
  parser.add_argument("--official", type=Path)
  parser.add_argument("--jax", type=Path)
  parser.add_argument("--port", type=int, default=None)
  parser.add_argument("--fps", type=float, default=20.0)
  args = parser.parse_args()

  official_path = args.official or Path(_DEFAULT_OFFICIAL.get(args.task, ""))
  jax_path = args.jax or Path(_DEFAULT_JAX.get(args.task, ""))
  if not official_path or not official_path.exists():
    parser.error(f"official trajectory not found; pass --official PATH (got {official_path})")
  if not jax_path or not jax_path.exists():
    parser.error(f"JAX trajectory not found; pass --jax PATH (got {jax_path})")

  task = parse_task_name(args.task)(seed=0)
  trajectories = {
      _label(official_path, "official FATROP"): _load_xs(official_path),
      _label(jax_path, "JAX PAS"): _load_xs(jax_path),
  }
  labels = list(trajectories)
  for label, xs in trajectories.items():
    if xs.shape[1] != task.nx:
      raise ValueError(
          f"{label}: state width {xs.shape[1]} does not match {args.task}.nx={task.nx}"
      )

  horizon = min(xs.shape[0] for xs in trajectories.values()) - 1
  if horizon < 0:
    raise ValueError("trajectories must contain at least one state")

  server_kwargs = {} if args.port is None else {"port": args.port}
  server = viser.ViserServer(**server_kwargs)
  scene = mjviser.ViserMujocoScene(server, task.model, num_envs=1)
  scene.camera_tracking_enabled = False

  solver = server.gui.add_dropdown("trajectory", options=labels, initial_value=labels[0])
  timestep = server.gui.add_slider(
      "timestep", min=0, max=horizon, step=1, initial_value=0
  )
  playing = server.gui.add_checkbox("play", initial_value=False)
  speed = server.gui.add_slider("speed (frames/sec)", min=1, max=120, step=1, initial_value=args.fps)
  status = server.gui.add_text("status", initial_value="")

  render_lock = threading.Lock()
  current_k = 0

  def render(k: int | None = None) -> None:
    nonlocal current_k
    with render_lock:
      if k is not None:
        current_k = max(0, min(int(k), horizon))
      xs = trajectories[solver.value]
      # The task's horizon can exceed a shortened/cache trajectory. Use the
      # common prefix for all task-specific plots and the MuJoCo scene.
      kk = min(current_k, xs.shape[0] - 1)
      state = xs[kk]
      model = task.model
      data = mujoco.MjData(model)
      data.qpos[:] = state[: model.nq]
      if model.nv:
        data.qvel[:] = state[model.nq:model.nq + model.nv]
      if model.na:
        data.act[:] = state[model.nq + model.nv:model.nx]
      mujoco.mj_forward(model, data)
      scene.update_from_mjdata(data)
      task._update_visualization(server, kk, xs)
      status.value = f"{solver.value}  |  frame {kk}/{xs.shape[0] - 1}"

  @solver.on_update
  def _(_event) -> None:
    render()

  @timestep.on_update
  def _(_event) -> None:
    render(timestep.value)

  def autoplay() -> None:
    while True:
      time.sleep(1.0 / max(float(speed.value), 1.0))
      if not playing.value:
        continue
      next_k = (current_k + 1) % (horizon + 1)
      timestep.value = next_k

  render(0)
  threading.Thread(target=autoplay, daemon=True).start()
  print(f"Viser server started at http://localhost:{server.get_port()}")
  print("Use the trajectory dropdown to switch solvers, timestep to scrub, and play to animate.")
  server.sleep_forever()


if __name__ == "__main__":
  main()
