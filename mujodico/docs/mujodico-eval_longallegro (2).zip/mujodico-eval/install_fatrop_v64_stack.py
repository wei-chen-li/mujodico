#!/usr/bin/env python3
"""Install only the already-validated FATROP fidelity pieces needed by v64.

This does NOT replace solver.py.  It preserves all newer SOC/PAS/KKT changes.
It installs missing prerequisites only:
  v29 checkpoint machinery -> validated v37 restoration module -> v44 handoff
then applies the v64 off-by-one watchdog timing fix.
"""
from __future__ import annotations
import argparse
import shutil
from pathlib import Path

from apply_fatrop_v29_watchdog_patch import apply_patch as apply_v29
from apply_fatrop_v44_integration_patch import apply_patch as apply_v44
from apply_fatrop_v64_watchdog_timing_patch import apply_patch as apply_v64


def solver_path() -> Path:
    import mujodico.trajopt._src.fatrop_ref.solver as sm
    return Path(sm.__file__).resolve()


def ensure_restoration(sp: Path) -> None:
    target = sp.with_name("restoration_v32.py")
    src = Path(__file__).with_name("restoration_v37.py")
    good = target.exists() and "V37_PAIR_CONDENSATION" in target.read_text(errors="ignore")
    if good:
        print(f"Validated v37 restoration already installed: {target}")
        return
    backup = target.with_name(target.name + ".pre_v64_stack.bak")
    if target.exists() and not backup.exists():
        shutil.copy2(target, backup)
    shutil.copy2(src, target)
    print(f"Installed validated v37 restoration as: {target}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--solver-path", default="")
    a = ap.parse_args()
    sp = Path(a.solver_path).resolve() if a.solver_path else solver_path()
    txt = sp.read_text()
    if "# V29_EXACT_WATCHDOG_RETRY" not in txt:
        apply_v29(sp)
    else:
        print("V29 checkpoint machinery already present")
    ensure_restoration(sp)
    txt = sp.read_text()
    if "# V44_INTEGRATED_NATIVE_RESTORATION" not in txt:
        apply_v44(sp)
    else:
        print("V44 restoration integration already present")
    apply_v64(sp)
    final = sp.read_text()
    required = [
        "# V29_EXACT_WATCHDOG_RETRY",
        "# V44_INTEGRATED_NATIVE_RESTORATION",
        "# V64_NATIVE_WATCHDOG_EXHAUSTION_TIMING",
    ]
    missing = [m for m in required if m not in final]
    if missing:
        raise RuntimeError(f"Installation verification failed; missing {missing}")
    print("V64 stack verification passed")


if __name__ == "__main__":
    main()
