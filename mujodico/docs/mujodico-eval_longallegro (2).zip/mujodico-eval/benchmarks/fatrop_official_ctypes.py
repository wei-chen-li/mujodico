"""Low-level official FATROP adapter for the MuJoDiCo contact benchmark.

This binds FATROP's exported ``fatrop_ocp_c_*`` C OCP interface with ctypes.
The nonlinear model and first derivatives are evaluated by JAX/MJX, while the
nonlinear IPM/globalization and generalized Riccati recursion are the official
FATROP implementation from libfatrop.so.

The stage Hessian supplied to official FATROP is the same Gauss--Newton / cost
curvature used by the JAX reference solver: 2R on physical controls, zero on
lifted contact forces, and 2Q / 2Qf on states.  No second derivatives of MJX
contact dynamics or constraints are used.
"""
from __future__ import annotations

import ctypes as ct
import ctypes.util
from dataclasses import dataclass
import os
from pathlib import Path
import time
from typing import Optional

import jax
import jax.numpy as jnp
import numpy as np


_c_int = ct.c_int
_c_double = ct.c_double
_c_void_p = ct.c_void_p
_DBLP = ct.POINTER(_c_double)

# Callback signatures from fatrop/ocp/OCPCInterface.h.
GET_DIM_K = ct.CFUNCTYPE(_c_int, _c_int, _c_void_p)
GET_DIM = ct.CFUNCTYPE(_c_int, _c_void_p)
GET_DOUBLE_K = ct.CFUNCTYPE(_c_int, _DBLP, _c_int, _c_void_p)
GET_DOUBLE = ct.CFUNCTYPE(_c_int, _DBLP, _c_void_p)
EVAL_BABT = ct.CFUNCTYPE(_c_int, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _c_void_p, _c_int, _c_void_p)
EVAL_RSQ = ct.CFUNCTYPE(_c_int, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _c_void_p, _c_int, _c_void_p)
EVAL_GGT = ct.CFUNCTYPE(_c_int, _DBLP, _DBLP, _DBLP, _DBLP, _c_void_p, _c_int, _c_void_p)
EVAL_B = ct.CFUNCTYPE(_c_int, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _c_int, _c_void_p)
EVAL_G = ct.CFUNCTYPE(_c_int, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _c_int, _c_void_p)
EVAL_RQ = ct.CFUNCTYPE(_c_int, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _c_int, _c_void_p)
EVAL_L = ct.CFUNCTYPE(_c_int, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _DBLP, _c_int, _c_void_p)
GET_BOUNDS_K = ct.CFUNCTYPE(_c_int, _DBLP, _DBLP, _c_int, _c_void_p)
WRITE_CB = ct.CFUNCTYPE(None, ct.c_char_p, _c_int)
FLUSH_CB = ct.CFUNCTYPE(None)


class FatropOcpCInterface(ct.Structure):
    _fields_ = [
        ("get_nx", GET_DIM_K),
        ("get_nu", GET_DIM_K),
        ("get_ng", GET_DIM_K),
        ("get_n_stage_params", GET_DIM_K),
        ("get_n_global_params", GET_DIM),
        ("get_default_stage_params", GET_DOUBLE_K),
        ("get_default_global_params", GET_DOUBLE),
        ("get_ng_ineq", GET_DIM_K),
        ("get_horizon_length", GET_DIM),
        ("eval_BAbt", EVAL_BABT),
        ("eval_RSQrqt", EVAL_RSQ),
        ("eval_Ggt", EVAL_GGT),
        ("eval_Ggt_ineq", EVAL_GGT),
        ("eval_b", EVAL_B),
        ("eval_g", EVAL_G),
        ("eval_gineq", EVAL_G),
        ("eval_rq", EVAL_RQ),
        ("eval_L", EVAL_L),
        ("get_bounds", GET_BOUNDS_K),
        ("get_initial_xk", GET_DOUBLE_K),
        ("get_initial_uk", GET_DOUBLE_K),
        ("full_eval_lag_hess", _c_void_p),
        ("full_eval_constr_jac", _c_void_p),
        ("full_eval_contr_viol", _c_void_p),
        ("full_eval_obj_grad", _c_void_p),
        ("full_eval_obj", _c_void_p),
        ("user_data", _c_void_p),
    ]


class FatropOcpCDims(ct.Structure):
    _fields_ = [
        ("ux_offs", ct.POINTER(_c_int)),
        ("g_offs", ct.POINTER(_c_int)),
        ("dyn_offs", ct.POINTER(_c_int)),
        ("dyn_eq_offs", ct.POINTER(_c_int)),
        ("g_ineq_offs", ct.POINTER(_c_int)),
        ("ineq_offs", ct.POINTER(_c_int)),
        ("max_nu", _c_int), ("max_nx", _c_int), ("max_ng", _c_int),
        ("max_ngineq", _c_int), ("n_ineqs", _c_int), ("K", _c_int),
        ("nu", ct.POINTER(_c_int)), ("nx", ct.POINTER(_c_int)),
        ("ng", ct.POINTER(_c_int)), ("ng_ineq", ct.POINTER(_c_int)),
    ]


class FatropOcpCStats(ct.Structure):
    _fields_ = [
        ("compute_sd_time", _c_double), ("duinf_time", _c_double),
        ("eval_hess_time", _c_double), ("eval_jac_time", _c_double),
        ("eval_cv_time", _c_double), ("eval_grad_time", _c_double),
        ("eval_obj_time", _c_double), ("initialization_time", _c_double),
        ("time_total", _c_double),
        ("eval_hess_count", _c_int), ("eval_jac_count", _c_int),
        ("eval_cv_count", _c_int), ("eval_grad_count", _c_int),
        ("eval_obj_count", _c_int), ("iterations_count", _c_int),
        ("return_flag", _c_int),
    ]


@dataclass
class OfficialFatropResult:
    x: np.ndarray
    u: np.ndarray
    wall_time: float
    stats: dict


def _discover_library(name: str, explicit: Optional[str]) -> str:
    if explicit:
        return explicit
    env = os.environ.get(name.upper() + "_LIB")
    if env:
        return env
    # CasADi wheels bundle both FATROP and BLASFEO.  This is only discovery;
    # the adapter does not otherwise depend on CasADi.
    try:
        import casadi  # type: ignore
        p = Path(casadi.__file__).resolve().parent / ("libfatrop.so" if name == "fatrop" else "libblasfeo.so")
        if p.exists():
            return str(p)
    except Exception:
        pass
    found = ctypes.util.find_library(name)
    if found:
        return found
    raise RuntimeError(
        f"Could not locate lib{name}.so. Set {name.upper()}_LIB=/absolute/path/lib{name}.so"
    )


def _arr(ptr, n: int) -> np.ndarray:
    if n == 0:
        return np.empty((0,), dtype=np.float64)
    return np.ctypeslib.as_array(ptr, shape=(n,))


class OfficialFatropContact:
    """Official FATROP low-level solver using the same lifted contact OCP."""

    def __init__(self, problem, *, fatrop_lib: str | None = None, blasfeo_lib: str | None = None,
                 print_level: int = 0):
        if problem.dtype != jnp.float64:
            raise ValueError("Official FATROP/BLASFEO interface is double precision; use float64.")
        self.p = problem
        self.task = problem.task
        self.N = int(self.task.horizon)
        self.K = self.N + 1
        self.nx = int(self.task.nx)
        self.nua = int(self.task.nu + problem.ncf)
        self.ne_contact = int(problem.ncf)
        self.ni = int(problem.ref.ni)
        self.print_level = int(print_level)
        self._last_error: Exception | None = None
        self._lin_cache = [None] * self.N

        self._blasfeo_path = _discover_library("blasfeo", blasfeo_lib)
        self._fatrop_path = _discover_library("fatrop", fatrop_lib)
        self.blas = ct.CDLL(self._blasfeo_path, mode=ct.RTLD_GLOBAL)
        self.lib = ct.CDLL(self._fatrop_path, mode=ct.RTLD_GLOBAL)
        self._bind_libs()
        self._build_jax_kernels()
        self._build_callbacks()
        self.solver = self.lib.fatrop_ocp_c_create(ct.byref(self.iface), None, None)
        if not self.solver:
            raise RuntimeError("fatrop_ocp_c_create returned NULL")
        self.set_option("print_level", self.print_level, required=False)

    def close(self):
        if getattr(self, "solver", None):
            self.lib.fatrop_ocp_c_destroy(self.solver)
            self.solver = None

    def __del__(self):
        try: self.close()
        except Exception: pass

    def _bind_libs(self):
        self.blas.blasfeo_pack_dmat.argtypes = [_c_int, _c_int, _DBLP, _c_int, _c_void_p, _c_int, _c_int]
        self.blas.blasfeo_pack_dmat.restype = None
        self.blas.blasfeo_unpack_dvec.argtypes = [_c_int, _c_void_p, _c_int, _DBLP, _c_int]
        self.blas.blasfeo_unpack_dvec.restype = None
        self.lib.fatrop_ocp_c_create.argtypes = [ct.POINTER(FatropOcpCInterface), _c_void_p, _c_void_p]
        self.lib.fatrop_ocp_c_create.restype = _c_void_p
        self.lib.fatrop_ocp_c_solve.argtypes = [_c_void_p]; self.lib.fatrop_ocp_c_solve.restype = _c_int
        self.lib.fatrop_ocp_c_destroy.argtypes = [_c_void_p]; self.lib.fatrop_ocp_c_destroy.restype = None
        self.lib.fatrop_ocp_c_option_type.argtypes = [ct.c_char_p]; self.lib.fatrop_ocp_c_option_type.restype = _c_int
        for nm, typ in [("double", _c_double), ("int", _c_int), ("bool", _c_int)]:
            fn = getattr(self.lib, f"fatrop_ocp_c_set_option_{nm}")
            fn.argtypes = [_c_void_p, ct.c_char_p, typ]; fn.restype = _c_int
        self.lib.fatrop_ocp_c_set_option_string.argtypes = [_c_void_p, ct.c_char_p, ct.c_char_p]
        self.lib.fatrop_ocp_c_set_option_string.restype = _c_int
        self.lib.fatrop_ocp_c_get_primal.argtypes = [_c_void_p]; self.lib.fatrop_ocp_c_get_primal.restype = _c_void_p
        self.lib.fatrop_ocp_c_get_dims.argtypes = [_c_void_p]; self.lib.fatrop_ocp_c_get_dims.restype = ct.POINTER(FatropOcpCDims)
        self.lib.fatrop_ocp_c_get_stats.argtypes = [_c_void_p]; self.lib.fatrop_ocp_c_get_stats.restype = ct.POINTER(FatropOcpCStats)

    def _pack_mat(self, M: np.ndarray, out):
        F = np.asfortranarray(M, dtype=np.float64)
        m, n = F.shape
        self.blas.blasfeo_pack_dmat(m, n, F.ctypes.data_as(_DBLP), m, out, 0, 0)

    def _build_jax_kernels(self):
        p = self.p
        def lin(x, u):
            f = p.transition(x, u)
            A, B = jax.jacfwd(p.transition, argnums=(0, 1))(x, u)
            e = p.stage_eq(x, u)
            E, F = jax.jacfwd(p.stage_eq, argnums=(0, 1))(x, u)
            h = p.stage_ineq(x, u)
            Gx, Gu = jax.jacfwd(p.stage_ineq, argnums=(0, 1))(x, u)
            return f, A, B, e, E, F, h, Gx, Gu
        self._lin = jax.jit(lin)
        # Warm once.  Timing of the official solver should not include JAX compilation.
        x0, u0 = p.init()
        if self.N:
            out = self._lin(jnp.asarray(x0[0]), jnp.asarray(u0[0]))
            jax.block_until_ready(out[0])

        self.Q = np.asarray(self.task.Q, dtype=np.float64)
        self.Qf = np.asarray(self.task.Qf, dtype=np.float64)
        self.R = np.asarray(self.task.R, dtype=np.float64)
        self.xg = np.asarray(self.task.x_goal, dtype=np.float64)
        self.ur = np.asarray(self.task.u_ref, dtype=np.float64)
        self.xinit, self.uinit = p.init()
        self.ilb = np.asarray(p.ineq_lb, dtype=np.float64)
        self.iub = np.asarray(p.ineq_ub, dtype=np.float64)

    def _linearize(self, k: int, x: np.ndarray, u: np.ndarray):
        # FATROP frequently asks several stage functions at the same point.
        c = self._lin_cache[k]
        if c is not None and np.array_equal(c[0], x) and np.array_equal(c[1], u):
            return c[2]
        out = self._lin(jnp.asarray(x), jnp.asarray(u))
        vals = tuple(np.asarray(v, dtype=np.float64) for v in out)
        self._lin_cache[k] = (x.copy(), u.copy(), vals)
        return vals

    def _cost(self, k, x, u):
        if k == self.N:
            e = x - self.xg
            return float(e @ self.Qf @ e)
        e = x - self.xg; du = u[:self.task.nu] - self.ur
        return float(e @ self.Q @ e + du @ self.R @ du)

    def _cost_grad_hess(self, k, x, u, scale):
        if k == self.N:
            gx = 2.0 * self.Qf @ (x - self.xg)
            H = 2.0 * self.Qf
            return scale * gx, scale * H
        gu = np.zeros(self.nua); gu[:self.task.nu] = 2.0 * self.R @ (u[:self.task.nu] - self.ur)
        gx = 2.0 * self.Q @ (x - self.xg)
        H = np.zeros((self.nua + self.nx, self.nua + self.nx))
        H[:self.task.nu, :self.task.nu] = 2.0 * self.R
        H[self.nua:, self.nua:] = 2.0 * self.Q
        return scale * np.concatenate([gu, gx]), scale * H

    def _build_callbacks(self):
        N, K, nx, nua, ne_c, ni = self.N, self.K, self.nx, self.nua, self.ne_contact, self.ni
        x0fix = np.asarray(self.task.x_0, dtype=np.float64)

        def guard(fn):
            def w(*args):
                try: return int(fn(*args))
                except Exception as e:
                    self._last_error = e
                    print(f"[official FATROP callback error] {type(e).__name__}: {e}", flush=True)
                    return 1
            return w

        self.cb_get_nx = GET_DIM_K(lambda k, ud: 0 if k == 0 else nx)
        self.cb_get_nu = GET_DIM_K(lambda k, ud: nua if k < N else 0)
        self.cb_get_ng = GET_DIM_K(lambda k, ud: ne_c if k < N else 0)
        self.cb_get_nsparam = GET_DIM_K(lambda k, ud: 0)
        self.cb_get_nglobal = GET_DIM(lambda ud: 0)
        self.cb_get_def_sp = GET_DOUBLE_K(lambda ptr, k, ud: 0)
        self.cb_get_def_gp = GET_DOUBLE(lambda ptr, ud: 0)
        self.cb_get_ni = GET_DIM_K(lambda k, ud: ni if k < N else 0)
        self.cb_get_K = GET_DIM(lambda ud: K)

        @guard
        def eval_BAbt(xp1p, up, xp, sp, gp, res, k, ud):
            x = x0fix.copy() if k == 0 else _arr(xp, nx).copy(); u = _arr(up, nua).copy(); xn = _arr(xp1p, nx).copy()
            f,A,B,*_ = self._linearize(k,x,u)
            M = np.vstack([B.T, (A.T if k > 0 else np.zeros((0,nx))), (f-xn)[None,:]])
            self._pack_mat(M,res); return 0
        self.cb_BAbt = EVAL_BABT(eval_BAbt)

        @guard
        def eval_RSQ(scale_p, up, xp, ld, le, li, sp, gp, res, k, ud):
            nu = nua if k < N else 0
            nxk = 0 if k == 0 else nx
            x = x0fix.copy() if k == 0 else _arr(xp,nx).copy(); u = _arr(up,nu).copy()
            sc = float(scale_p[0]) if bool(scale_p) else 1.0
            grad_full,H_full = self._cost_grad_hess(k,x,u,sc)
            if k == 0:
                grad = grad_full[:nua]; H = H_full[:nua,:nua]
            else:
                grad,H = grad_full,H_full
            M = np.vstack([H,grad[None,:]])
            self._pack_mat(M,res); return 0
        self.cb_RSQ = EVAL_RSQ(eval_RSQ)

        def eq_data(k,x,u):
            _,_,_,e,E,F,_,_,_ = self._linearize(k,x,u)
            # x0 is structural/fixed in the low-level OCP: stage 0 has nx=0.
            if k == 0:
                return e, np.zeros((ne_c,0),dtype=np.float64), F
            return e,E,F

        @guard
        def eval_Ggt(up,xp,sp,gp,res,k,ud):
            if k >= N: return 0
            x=x0fix.copy() if k==0 else _arr(xp,nx).copy();u=_arr(up,nua).copy();g,Gx,Gu=eq_data(k,x,u)
            M=np.vstack([Gu.T,Gx.T,g[None,:]])
            self._pack_mat(M,res);return 0
        self.cb_Ggt=EVAL_GGT(eval_Ggt)

        @guard
        def eval_Ggt_i(up,xp,sp,gp,res,k,ud):
            if k>=N:return 0
            x=x0fix.copy() if k==0 else _arr(xp,nx).copy();u=_arr(up,nua).copy();*_,h,Gx,Gu=self._linearize(k,x,u)
            if k==0: Gx=np.zeros((ni,0),dtype=np.float64)
            M=np.vstack([Gu.T,Gx.T,h[None,:]])
            self._pack_mat(M,res);return 0
        self.cb_Ggti=EVAL_GGT(eval_Ggt_i)

        @guard
        def eval_b(xp1p,up,xp,sp,gp,out,k,ud):
            x=x0fix.copy() if k==0 else _arr(xp,nx).copy();u=_arr(up,nua).copy();xn=_arr(xp1p,nx)
            f,*_=self._linearize(k,x,u);_arr(out,nx)[:] = f-xn;return 0
        self.cb_b=EVAL_B(eval_b)

        @guard
        def eval_g(up,xp,sp,gp,out,k,ud):
            if k>=N:return 0
            x=x0fix.copy() if k==0 else _arr(xp,nx).copy();u=_arr(up,nua).copy();g,_,_=eq_data(k,x,u);_arr(out,g.size)[:]=g;return 0
        self.cb_g=EVAL_G(eval_g)

        @guard
        def eval_gi(up,xp,sp,gp,out,k,ud):
            if k>=N:return 0
            x=x0fix.copy() if k==0 else _arr(xp,nx).copy();u=_arr(up,nua).copy();*_,h,_,_=self._linearize(k,x,u);_arr(out,ni)[:]=h;return 0
        self.cb_gi=EVAL_G(eval_gi)

        @guard
        def eval_rq(scale_p,up,xp,sp,gp,out,k,ud):
            nu=nua if k<N else 0; nxk=0 if k==0 else nx; x=x0fix.copy() if k==0 else _arr(xp,nx).copy();u=_arr(up,nu).copy();sc=float(scale_p[0]) if bool(scale_p) else 1.0
            grad,_=self._cost_grad_hess(k,x,u,sc); grad = grad[:nua] if k==0 else grad; _arr(out,nu+nxk)[:]=grad;return 0
        self.cb_rq=EVAL_RQ(eval_rq)

        @guard
        def eval_L(scale_p,up,xp,sp,gp,out,k,ud):
            nu=nua if k<N else 0;x=x0fix.copy() if k==0 else _arr(xp,nx).copy();u=_arr(up,nu).copy();sc=float(scale_p[0]) if bool(scale_p) else 1.0
            out[0]=sc*self._cost(k,x,u);return 0
        self.cb_L=EVAL_L(eval_L)

        @guard
        def get_bounds(lo,hi,k,ud):
            if k<N and ni:
                _arr(lo,ni)[:]=self.ilb;_arr(hi,ni)[:]=self.iub
            return 0
        self.cb_bounds=GET_BOUNDS_K(get_bounds)

        @guard
        def get_x(out,k,ud):
            if k>0:_arr(out,nx)[:] = self.xinit[k]
            return 0
        @guard
        def get_u(out,k,ud):
            if k<N:_arr(out,nua)[:] = self.uinit[k]
            return 0
        self.cb_initx=GET_DOUBLE_K(get_x);self.cb_initu=GET_DOUBLE_K(get_u)

        # Keep every CFUNCTYPE object referenced by self for the solver lifetime.
        self.iface=FatropOcpCInterface(
            self.cb_get_nx,self.cb_get_nu,self.cb_get_ng,self.cb_get_nsparam,self.cb_get_nglobal,
            self.cb_get_def_sp,self.cb_get_def_gp,self.cb_get_ni,self.cb_get_K,
            self.cb_BAbt,self.cb_RSQ,self.cb_Ggt,self.cb_Ggti,self.cb_b,self.cb_g,self.cb_gi,
            self.cb_rq,self.cb_L,self.cb_bounds,self.cb_initx,self.cb_initu,
            None,None,None,None,None,None)

    def set_option(self, name: str, value, *, required=True):
        typ = int(self.lib.fatrop_ocp_c_option_type(name.encode()))
        if typ < 0:
            if required: raise KeyError(f"Official FATROP has no option {name!r}")
            return False
        if typ == 0: ret=self.lib.fatrop_ocp_c_set_option_double(self.solver,name.encode(),float(value))
        elif typ == 1: ret=self.lib.fatrop_ocp_c_set_option_int(self.solver,name.encode(),int(value))
        elif typ == 2: ret=self.lib.fatrop_ocp_c_set_option_bool(self.solver,name.encode(),int(bool(value)))
        elif typ == 3: ret=self.lib.fatrop_ocp_c_set_option_string(self.solver,name.encode(),str(value).encode())
        else: raise RuntimeError(f"Unexpected FATROP option type {typ}")
        if ret and required: raise RuntimeError(f"Setting FATROP option {name} failed with code {ret}")
        return ret == 0

    def solve(self, *, max_iter=150, tol=1e-8, mu_init=1e-1) -> OfficialFatropResult:
        for name,val in [("max_iter",max_iter),("tol",tol),("mu_init",mu_init),("print_level",self.print_level)]:
            self.set_option(name,val,required=False)
        self._last_error=None; self._lin_cache=[None]*self.N
        t0=time.perf_counter(); flag=int(self.lib.fatrop_ocp_c_solve(self.solver)); wall=time.perf_counter()-t0
        if self._last_error is not None:
            raise RuntimeError("Official FATROP callback failed") from self._last_error
        stats_c=self.lib.fatrop_ocp_c_get_stats(self.solver).contents
        stats={f:getattr(stats_c,f) for f,_ in FatropOcpCStats._fields_}; stats["solve_return"]=flag
        dims=self.lib.fatrop_ocp_c_get_dims(self.solver).contents
        K=int(dims.K)
        offs=[int(dims.ux_offs[k]) for k in range(K)]
        sizes=[int(dims.nu[k]+dims.nx[k]) for k in range(K)]
        total=max(o+s for o,s in zip(offs,sizes))
        primal=np.empty(total,dtype=np.float64)
        self.blas.blasfeo_unpack_dvec(total,self.lib.fatrop_ocp_c_get_primal(self.solver),0,
                                     primal.ctypes.data_as(_DBLP),1)
        xs=np.empty((self.N+1,self.nx),dtype=np.float64); us=np.empty((self.N,self.nua),dtype=np.float64)
        xs[0]=np.asarray(self.task.x_0,dtype=np.float64)
        for k in range(K):
            off=offs[k];nu=int(dims.nu[k]);nxx=int(dims.nx[k]);blk=primal[off:off+nu+nxx]
            if k<self.N: us[k]=blk[:nu]
            if k>0: xs[k]=blk[nu:nu+nxx]
        return OfficialFatropResult(xs,us,wall,stats)
